import pandas as pd

def normalize_structure(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["metric"] = (out["metric"].astype("string").str.strip()
                     .str.replace(r"\s+", " ", regex=True))
    out["period"] = pd.to_datetime(out["period"], errors="coerce")
    out["value_numeric"] = pd.to_numeric(out["value"], errors="coerce")
    return out

# Statistical scaling belongs to the ML feature layer, not the Data Mart.
def scale_for_ml(X_train, X_test, method="standard"):
    from sklearn.preprocessing import StandardScaler, MinMaxScaler
    scaler = StandardScaler() if method == "standard" else MinMaxScaler()
    return scaler.fit_transform(X_train), scaler.transform(X_test), scaler
