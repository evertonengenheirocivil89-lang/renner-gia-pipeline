from pathlib import Path
import pandas as pd


def inventory_cvm_files(cvm_dir):
    rows = []
    for p in sorted(Path(cvm_dir).glob('*')):
        if p.is_file() and not p.name.startswith('.'):
            rows.append({'file': p.name, 'extension': p.suffix.lower(), 'path': str(p)})
    return pd.DataFrame(rows)


def read_tabular_file(path):
    """Generic reader for a local CVM file; document-specific mappings belong
    in separate parsers because units and statement concepts differ by form."""
    path = Path(path)
    if path.suffix.lower() == '.csv':
        return pd.read_csv(path)
    if path.suffix.lower() in {'.xlsx', '.xls'}:
        return pd.read_excel(path)
    raise ValueError(f'Formato não tabular suportado automaticamente: {path.suffix}')
