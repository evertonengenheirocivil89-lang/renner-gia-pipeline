import pandas as pd
from src.ingestion.ri_renner import classify_document, parse_period_from_name
from src.esg.metrics import validate_esg_columns
from src.models.validation import regression_metrics

def test_classify_document():
    assert classify_document("Resultado_1T2025.pdf") == "resultados"
    assert classify_document("Relatório Sustentabilidade 2025.pdf") == "relatorios"

def test_parse_period():
    assert parse_period_from_name("Resultado_1T2025.pdf") == "2025-03"
    assert parse_period_from_name("Release_2024.pdf") == "2024"

def test_esg_missing_is_explicit():
    result = validate_esg_columns(pd.DataFrame())
    assert not result.empty
    assert result["available_count"].iloc[0] == 0
    assert result["missing_count"].iloc[0] > 0

def test_metrics():
    p = pd.DataFrame({"actual":[1,2,3],"prediction":[1,3,2]})
    m = regression_metrics(p)
    assert m["n"] == 3
    assert m["mae"] == 2/3
