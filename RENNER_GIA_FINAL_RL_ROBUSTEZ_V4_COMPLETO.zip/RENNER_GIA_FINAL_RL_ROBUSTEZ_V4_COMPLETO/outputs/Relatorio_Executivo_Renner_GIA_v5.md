# Relatório Executivo — Renner GIA v5 — Decision Intelligence

## 1. Arquitetura
RAW → INGESTÃO → QUALIDADE → FILTRAGEM → NORMALIZAÇÃO ESTRUTURAL → DATA MART → FEATURES → FORECAST → ESG/CLIMA → ALERTAS → GIA.

## 2. Indicadores avançados
- **revenue_growth**: 0.8%
- **ebitda_margin**: N/D
- **net_margin**: 9.6%
- **assets_equity**: 1.84
- **cash_to_revenue**: 0.29

## 3. Tendência e volatilidade
As médias móveis e a volatilidade são calculadas sobre a série trimestral standalone produzida pela camada financeira, evitando misturar períodos acumulados com trimestres.

## 4. Alertas GIA
- **revenue_growth**: CONTROLE | valor=0.0081
- **net_margin**: CONTROLE | valor=0.0963

## 5. Previsão
- revenue: OK; próximos valores=[np.float64(3850490.02), np.float64(4003079.99), np.float64(3936745.8), np.float64(3965582.72)]
- net_income: OK; próximos valores=[np.float64(329999.55), np.float64(377697.69), np.float64(347218.77), np.float64(366694.68)]

A previsão ARIMA é exploratória. Antes de uso gerencial, deve passar por backtesting walk-forward e comparação com baseline.

## 6. ESG e clima — IFRS S1/S2 e CBPS 1/2
O relatório 2025 passa a ser uma fonte estruturada do GIA. Os dados abaixo são transcritos/estruturados da divulgação fornecida e não representam um score ESG criado pelo modelo.
### 6.1 Riscos climáticos
- **Ondas de calor** — impacto operacional 2025: R$ -10.0 mi; fluxo de caixa futuro: até R$ 110.0 mi; status: impacto mensurado.
- **Inundações e tempestades** — impacto operacional 2025: R$ 0.0 mi; fluxo de caixa futuro: até R$ 25.0 mi; status: sem impacto financeiro no exercício.
- **Incêndios florestais** — impacto operacional 2025: R$ 0.0 mi; fluxo de caixa futuro: N/D; status: sem impacto financeiro identificado.
- **Ventos fortes** — impacto operacional 2025: N/D; fluxo de caixa futuro: N/D; status: mensuração conforme relatório.
- **Secas meteorológicas** — impacto operacional 2025: R$ 0.0 mi; fluxo de caixa futuro: N/D; status: sem impacto financeiro identificado.
### 6.2 Inventário de emissões 2025
- Escopo 1 (Total): 7,033.11 tCO2e.
- Escopo 2 (Localização): 11,146.36 tCO2e.
- Escopo 2 (Escolha de compra): 0.00 tCO2e.
- Escopo 3 (Total reportado): 398,131.26 tCO2e.
### 6.3 Metas climáticas
- Escopos 1 e 2: redução de 46.2% até 2030; status 2025: submeta 2025 alcançada.
- Escopo 3 – bens e serviços adquiridos por peça: redução de 55.0% até 2030; status 2025: submeta 2025 não alcançada.
- Escopos 1, 2 e 3: redução de 90.0% até 2050; status 2025: meta de longo prazo.

## 7. Benchmarking
O pipeline permanece preparado para C&A, Riachuelo e Arezzo. Nenhum valor de concorrente é estimado sem fonte oficial comparável.

## 8. GIA
- **Governance:** rastreabilidade da fonte, qualidade dos dados e conexão com materialidade e governança de riscos.
- **Intelligence:** indicadores financeiros + riscos climáticos + emissões + metas + previsões.
- **Action:** alertas separados entre risco financeiro observado, risco projetado e monitoramento qualitativo.

## 9. Pontos de evolução
1. Fazer backtesting walk-forward dos modelos de previsão.
2. Integrar dados temporais de clima, lojas e geografia para modelar riscos físicos.
3. Conectar risco climático a receita, estoque, markdown, margem e fluxo de caixa.
4. Incorporar as métricas sociais e de governança quando os dados estruturados estiverem disponíveis.
5. Integrar pares somente com bases oficiais e métricas metodologicamente comparáveis.
