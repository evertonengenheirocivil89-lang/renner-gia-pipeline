import numpy as np
import pandas as pd

def _pick_metric(df, candidates):
    if df is None or df.empty or "metric" not in df.columns:
        return pd.DataFrame()
    wanted = {str(x).strip().casefold() for x in candidates}
    return df[df["metric"].astype(str).str.strip().str.casefold().isin(wanted)].copy()

def build_financial_mart(frames):
    specs = {
        "revenue": ("income_statement", ["Net Operating Revenues", "Gross Operating Revenues", "Net Revenue"]),
        "net_income": ("income_statement", ["Net Income", "Net profit for the period", "Net Profit"]),
        "assets": ("balance_sheet", ["Total Assets", "Ativo Total"]),
        "equity": ("balance_sheet", ["Shareholder's Equity", "Total Shareholders Equity", "Total Equity", "Shareholders Equity"]),
        "cash": ("balance_sheet", ["Cash & Cash Equivalents", "Cash and Cash Equivalents", "Cash"]),
        "ebitda": ("ebitda", ["EBITDA Total", "Adjusted EBITDA Total", "EBITDA"]),
        "roic": ("roic", ["% ROIC", "ROIC"]),
    }
    parts = []
    for name, (sheet, candidates) in specs.items():
        x = _pick_metric(frames.get(sheet, pd.DataFrame()), candidates)
        if not x.empty:
            x = x[["period","period_label","metric","value"]].copy()
            x["mart_metric"] = name
            x["source_sheet"] = sheet
            parts.append(x)
    return pd.concat(parts, ignore_index=True).sort_values(["period","mart_metric"]) if parts else pd.DataFrame()

def build_credit_mart(frames):
    parts = []
    for key in ["accounts_receivables", "credit_losses", "npl", "receivables_bacen", "financial_services"]:
        x = frames.get(key, pd.DataFrame())
        if x is not None and not x.empty:
            y = x.copy()
            y["credit_dataset"] = key
            parts.append(y)
    return pd.concat(parts, ignore_index=True, sort=False) if parts else pd.DataFrame()

def build_operational_mart(frames):
    parts = []
    for key in ["operating_data", "stores"]:
        x = frames.get(key, pd.DataFrame())
        if x is not None and not x.empty:
            y = x.copy()
            y["operational_dataset"] = key
            parts.append(y)
    return pd.concat(parts, ignore_index=True, sort=False) if parts else pd.DataFrame()

def build_esg_mart(esg_inventory):
    if esg_inventory is None or esg_inventory.empty:
        return pd.DataFrame(columns=["source","file","extension","status","esg_domain"])
    x = esg_inventory.copy()
    def domain(name):
        s = str(name).lower()
        if "govern" in s or "código" in s or "codigo" in s:
            return "governance"
        if "sustent" in s or "esg" in s or "integrado" in s:
            return "esg"
        return "documentary_evidence"
    x["esg_domain"] = x["file"].map(domain)
    x["observed_metric"] = False
    x["note"] = "documento disponível; nenhum score ESG sintético foi inferido"
    return x

def build_risk_mart(financial_mart):
    if financial_mart is None or financial_mart.empty:
        return pd.DataFrame()
    p = financial_mart.pivot_table(index="period", columns="mart_metric", values="value", aggfunc="last").sort_index()
    rows = []
    for idx, r in p.iterrows():
        revenue, net_income = r.get("revenue", np.nan), r.get("net_income", np.nan)
        assets, equity, cash = r.get("assets", np.nan), r.get("equity", np.nan), r.get("cash", np.nan)
        ebitda = r.get("ebitda", np.nan)
        rows.append({
            "period": idx,
            "net_margin": net_income/revenue if pd.notna(net_income) and pd.notna(revenue) and revenue != 0 else np.nan,
            "ebitda_margin": ebitda/revenue if pd.notna(ebitda) and pd.notna(revenue) and revenue != 0 else np.nan,
            "leverage_proxy": assets/equity if pd.notna(assets) and pd.notna(equity) and equity != 0 else np.nan,
            "cash_to_revenue": cash/revenue if pd.notna(cash) and pd.notna(revenue) and revenue != 0 else np.nan,
        })
    risk = pd.DataFrame(rows)
    risk["risk_flag_profitability"] = np.where(risk["net_margin"] < 0, "attention", "normal")
    risk["risk_flag_leverage"] = np.where(risk["leverage_proxy"] > 3, "attention", "normal")
    risk["risk_flag_liquidity_proxy"] = np.where(risk["cash_to_revenue"] < .05, "attention", "normal")
    return risk
