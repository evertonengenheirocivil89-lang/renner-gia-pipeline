import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error


def make_target(features, column='net_income', horizon=1):
    x = features.copy()
    if column not in x: return x, None
    target = x[column].shift(-horizon)
    return x, target


def chronological_split(X, y, test_size=0.2, min_train_rows=12):
    data = pd.concat([X, y.rename('target')], axis=1).dropna(subset=['target'])
    if len(data) < min_train_rows + 2:
        raise ValueError(f'Poucos dados para split temporal: {len(data)} linhas.')
    cut = max(min_train_rows, int(len(data) * (1-test_size)))
    cut = min(cut, len(data)-1)
    return data.iloc[:cut].drop(columns='target'), data.iloc[:cut]['target'], data.iloc[cut:].drop(columns='target'), data.iloc[cut:]['target']


def fit_ridge(X_train, y_train):
    model = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scale', StandardScaler()),
        ('model', Ridge(alpha=1.0)),
    ])
    model.fit(X_train, y_train)
    return model


def evaluate(model, X_test, y_test):
    pred = model.predict(X_test)
    return {
        'mae': float(mean_absolute_error(y_test, pred)),
        'rmse': float(mean_squared_error(y_test, pred) ** 0.5),
        'n_test': int(len(y_test)),
    }, pd.Series(pred, index=y_test.index, name='prediction')


def baseline(y_train, y_test):
    value = float(y_train.mean())
    pred = pd.Series(value, index=y_test.index)
    return {
        'mae': float(mean_absolute_error(y_test, pred)),
        'rmse': float(mean_squared_error(y_test, pred) ** 0.5),
        'n_test': int(len(y_test)),
    }, pred
