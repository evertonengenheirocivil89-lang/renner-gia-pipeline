import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error

def walk_forward_evaluate(df, target, feature_cols, model_factory, min_train=12, horizon=1):
    data = df.sort_values("period").dropna(subset=[target] + feature_cols).reset_index(drop=True)
    rows = []
    if len(data) <= min_train:
        return pd.DataFrame(columns=["period","actual","prediction"])
    for end in range(min_train, len(data) - horizon + 1):
        train = data.iloc[:end]
        test = data.iloc[end:end+horizon]
        model = model_factory()
        model.fit(train[feature_cols], train[target])
        pred = model.predict(test[feature_cols])
        rows.extend({"period": p, "actual": float(a), "prediction": float(y)} for p,a,y in zip(test["period"], test[target], pred))
    return pd.DataFrame(rows)

def regression_metrics(predictions):
    if predictions.empty:
        return {"mae": np.nan, "rmse": np.nan, "n": 0}
    y = predictions["actual"].to_numpy(); p = predictions["prediction"].to_numpy()
    return {"mae": float(mean_absolute_error(y,p)), "rmse": float(np.sqrt(mean_squared_error(y,p))), "n": int(len(y))}
