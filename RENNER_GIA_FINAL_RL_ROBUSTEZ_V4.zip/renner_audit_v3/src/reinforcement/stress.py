"""Cenários de estresse adverso para a avaliação model-based do RL.

O cenário é uma hipótese de estresse, não uma previsão nem um efeito causal.
Ele desloca os resíduos da transição em direções adversas para variáveis
financeiras modeladas e para volatilidade, mantendo a mesma política/guarda.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .environment import build_state, policy_guard, reward_from_transition, apply_action_scenario
from .trainer import greedy_policy

# Sinal adverso: menor crescimento/margem/ROIC/caixa; maior volatilidade/NPL/risco.
ADVERSE_SIGN = {
    "revenue_growth": -1.0,
    "net_margin": -1.0,
    "ebitda_margin": -1.0,
    "roic": -1.0,
    "cash_revenue": -1.0,
    "npl_ratio": 1.0,
    "inventory_growth": -1.0,
    "receivables_growth": -1.0,
    "revenue_volatility_4q": 1.0,
    "net_income_volatility_4q": 1.0,
    "climate_risk_score": 1.0,
}


def _stress_next(current, transition_model, action, rng, shock_sigma=1.0, pred=None):
    pred = transition_model.predict_next(current) if pred is None else pred
    nxt = current.copy()
    for col, value in pred.items():
        sigma = float(transition_model.residual_std.get(col, 0.0))
        if not np.isfinite(value):
            continue
        random_component = rng.normal(0.0, sigma) if sigma > 0 else 0.0
        adverse_component = ADVERSE_SIGN.get(col, 0.0) * shock_sigma * sigma
        nxt[col] = float(value) + random_component + adverse_component
    return apply_action_scenario(nxt, current, transition_model, action)


def simulate_stress_once(panel, q, transition_model, seed, shock_sigma=1.0, prediction_cache=None):
    rng = np.random.default_rng(seed)
    total = 0.0
    cost = 0.0
    rewards = []
    actions = []
    for i in range(len(panel) - 1):
        current = panel.iloc[i]
        raw = greedy_policy(q, build_state(current), current)
        action = policy_guard(raw, current)
        pred = prediction_cache.get(i) if prediction_cache is not None else None
        nxt = _stress_next(current, transition_model, action, rng, shock_sigma=shock_sigma, pred=pred)
        reward = reward_from_transition(current, nxt, action)
        total += reward
        cost += max(0.0, -reward)
        rewards.append(reward)
        actions.append(action)
    return {
        "seed": int(seed),
        "shock_sigma": float(shock_sigma),
        "total_reward": float(total),
        "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
        "cumulative_cost": float(cost),
        "negative_reward_rate": float(np.mean(np.asarray(rewards) < 0)) if rewards else 0.0,
        "action_switches": int(np.sum(np.diff(actions) != 0)) if len(actions) > 1 else 0,
        "unique_actions": int(len(set(actions))),
    }


def run_adverse_stress(panel, q, transition_model, n_simulations=250, seed=3030,
                       shock_sigma=1.0):
    if transition_model is None:
        raise ValueError("Cenário de estresse requer transition_model.")
    seeds = np.random.default_rng(seed).integers(0, 2**32 - 1, size=n_simulations, dtype=np.uint32)
    prediction_cache = {i: transition_model.predict_next(panel.iloc[i]) for i in range(len(panel) - 1)}
    df = pd.DataFrame([
        simulate_stress_once(panel, q, transition_model, int(s), shock_sigma=shock_sigma, prediction_cache=prediction_cache)
        for s in seeds
    ])
    summary = {
        "stress_type": "adverse_residual_shift",
        "stress_shock_sigma": float(shock_sigma),
        "stress_n_simulations": int(len(df)),
        "stress_total_reward_mean": float(df.total_reward.mean()),
        "stress_total_reward_p05": float(df.total_reward.quantile(.05)),
        "stress_total_reward_p50": float(df.total_reward.quantile(.50)),
        "stress_total_reward_p95": float(df.total_reward.quantile(.95)),
        "stress_cumulative_cost_mean": float(df.cumulative_cost.mean()),
        "stress_cumulative_cost_p95": float(df.cumulative_cost.quantile(.95)),
        "stress_negative_reward_rate_mean": float(df.negative_reward_rate.mean()),
        "stress_negative_reward_rate_p95": float(df.negative_reward_rate.quantile(.95)),
        "evaluation_mode": "adverse_model_based_stress_simulation",
    }
    return df, summary
