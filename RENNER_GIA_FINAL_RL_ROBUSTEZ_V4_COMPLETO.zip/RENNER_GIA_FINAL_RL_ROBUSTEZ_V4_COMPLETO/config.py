from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
RAW = DATA / 'raw'
PROCESSED = DATA / 'processed'
FEATURES = DATA / '07_features'
OUTPUTS = ROOT / 'outputs'
RI_URL = 'https://ri.lojasrenner.com.br/'

WORKBOOK = RAW / 'Planilhas e Fundamentos.xlsx'

SHEETS = {
    'balance_sheet': 'Balance Sheet',
    'income_statement': 'Income Statement',
    'cash_flow': 'Cash Flow',
    'accounts_receivables': 'Accounts Receivables',
    'credit_losses': 'Estimated Credit Losses IFRS',
    'npl': 'NPL Formation',
    'financial_services': 'Financial Services',
    'ebitda': 'EBITDA',
    'ebitda_ex_ifrs16': 'EBITDA Ex-IFRS 16',
    'operating_data': 'Operating Data',
    'stores': 'B&M Units',
    'roic': 'ROIC',
    'capex': 'CAPEX',
    'dividends': 'Dividends and IOC',
    'receivables_bacen': 'Receivables BACEN',
    'uf': 'UF',
    'quarters': 'Quarters',
}

# A lista abaixo é deliberadamente conservadora. O pipeline nunca cria ESG
# sintético quando não existe uma fonte observada.
FLOW_SHEETS = {'income_statement', 'cash_flow', 'financial_services', 'ebitda', 'ebitda_ex_ifrs16', 'capex'}
STOCK_SHEETS = {'balance_sheet', 'accounts_receivables', 'credit_losses', 'npl', 'receivables_bacen'}

TARGET_METRICS = {
    'revenue': ['Net Operating Revenues', 'Gross Operating Revenues', 'Net Revenue'],
    'net_income': ['Net Income', 'Net profit for the period', 'Net Profit'],
    'ebitda': ['EBITDA Total', 'Adjusted EBITDA Total', 'EBITDA'],
    'assets': ['Total Assets', 'Ativo Total'],
    'equity': ["Shareholder's Equity", 'Total Shareholders Equity', 'Total Equity', 'Shareholders Equity'],
    'cash': ['Cash & Cash Equivalents', 'Cash and Cash Equivalents', 'Cash'],
}

RANDOM_SEED = 42
TEST_SIZE = 0.20
MIN_TRAIN_ROWS = 12
