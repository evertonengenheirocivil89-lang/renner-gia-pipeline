import numpy as np
import pandas as pd
import warnings
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.linear_model import Ridge
from statsmodels.tsa.arima.model import ARIMA

def walk_forward_evaluate(df, target, feature_cols, model_factory, min_train=12, horizon=1):
    data = df.sort_values("period").dropna(subset=[target] + feature_cols).reset_index(drop=True)
    rows = []
    if len(data) <= min_train:
        return pd.DataFrame(columns=["period","actual","prediction"])
    for end in range(min_train, len(data) - horizon + 1):
        train = data.iloc[:end]
        test = data.iloc[end:end+horizon]
        model = model_factory()
        model.fit(train[feature_cols], train[target])
        pred = model.predict(test[feature_cols])
        rows.extend({"period": p, "actual": float(a), "prediction": float(y)} for p,a,y in zip(test["period"], test[target], pred))
    return pd.DataFrame(rows)

def regression_metrics(predictions):
    if predictions.empty:
        return {"mae": np.nan, "rmse": np.nan, "n": 0}
    y = predictions["actual"].to_numpy(); p = predictions["prediction"].to_numpy()
    return {"mae": float(mean_absolute_error(y,p)), "rmse": float(np.sqrt(mean_squared_error(y,p))), "n": int(len(y))}


def _smape(y_true, y_pred):
    y = np.asarray(y_true, dtype=float)
    p = np.asarray(y_pred, dtype=float)
    denom = np.abs(y) + np.abs(p)
    valid = denom > 0
    if not np.any(valid):
        return 0.0
    return float(np.mean(2.0 * np.abs(p[valid] - y[valid]) / denom[valid]) * 100.0)


def forecast_metrics(predictions):
    """Métricas temporais comuns para comparar modelos no mesmo conjunto de teste."""
    if predictions.empty:
        return {"mae": np.nan, "rmse": np.nan, "smape": np.nan, "bias": np.nan, "n": 0}
    y = predictions["actual"].to_numpy(dtype=float)
    p = predictions["prediction"].to_numpy(dtype=float)
    return {
        "mae": float(mean_absolute_error(y, p)),
        "rmse": float(np.sqrt(mean_squared_error(y, p))),
        "smape": _smape(y, p),
        "bias": float(np.mean(p - y)),
        "n": int(len(y)),
    }


def compare_revenue_forecasts(df, target="revenue", min_train=12, ridge_alpha=1.0,
                              arima_order=(1, 1, 1)):
    """Walk-forward one-step: baseline ingênuo, ARIMA e Ridge usam o mesmo horizonte.

    O baseline usa o último valor observado; Ridge usa apenas o lag-1 para manter
    a comparação temporal limpa. ARIMA é reajustado a cada ponto de teste.
    """
    if target not in df.columns:
        return pd.DataFrame(), pd.DataFrame()
    data = df.sort_index()[[target]].copy()
    data[target] = pd.to_numeric(data[target], errors="coerce")
    data = data.dropna().reset_index().rename(columns={data.index.name or "index": "period"})
    if len(data) <= min_train:
        return pd.DataFrame(), pd.DataFrame()
    rows = []
    for end in range(min_train, len(data)):
        train = data.iloc[:end].copy()
        test = data.iloc[end]
        actual = float(test[target])
        last = float(train[target].iloc[-1])
        rows.append({"period": test["period"], "actual": actual, "prediction": last, "model": "baseline"})
        x = train[target].shift(1).dropna().to_frame("lag_1")
        y = train.loc[x.index, target]
        if len(x) >= max(8, min_train - 2):
            ridge = Ridge(alpha=ridge_alpha).fit(x, y)
            pred = float(ridge.predict(pd.DataFrame({"lag_1": [last]}))[0])
            rows.append({"period": test["period"], "actual": actual, "prediction": pred, "model": "ridge"})
        if len(train) >= min_train:
            try:
                series = train[target]
                if isinstance(train["period"].iloc[0], pd.Timestamp):
                    series.index = pd.PeriodIndex(train["period"], freq="Q")
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    arima = ARIMA(series, order=arima_order).fit()
                pred = float(arima.forecast(1).iloc[0])
                rows.append({"period": test["period"], "actual": actual, "prediction": pred, "model": "arima"})
            except Exception:
                # Não inventa previsão quando o ARIMA não converge naquele corte.
                pass
    pred_df = pd.DataFrame(rows)
    metric_rows = []
    for model, grp in pred_df.groupby("model"):
        m = forecast_metrics(grp)
        m["model"] = model
        metric_rows.append(m)
    metrics = pd.DataFrame(metric_rows)[["model", "mae", "rmse", "smape", "bias", "n"]]
    return pred_df, metrics
