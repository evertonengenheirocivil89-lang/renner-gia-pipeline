import numpy as np
import pandas as pd
from .environment import RennerDecisionEnv, ACTIONS, build_state
from .trainer import greedy_policy, policy_guard

def evaluate_policy(panel: pd.DataFrame, q, transition_model=None, start=0, end=None):
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    end = len(panel) - 1 if end is None else min(end, len(panel) - 1)
    env.reset(start); rows = []; total = 0.0; cumulative_cost = 0.0; guard_interventions = 0
    while env.i < end:
        current = env.panel.iloc[env.i]
        state = build_state(current)
        action = greedy_policy(q, state, current)
        next_state, reward, done, info = env.step(action)
        total += reward
        cumulative_cost += max(0.0, -reward)
        rows.append({"period": info.get("period"), "action_id": action, "action": ACTIONS[action],
                     "reward": reward, "cumulative_reward": total, "cumulative_cost": cumulative_cost,
                     "simulated": info.get("simulated", False)})
        if done: break
    result = pd.DataFrame(rows)
    metrics = {"total_reward": float(result["reward"].sum()) if not result.empty else 0.0,
               "mean_reward": float(result["reward"].mean()) if not result.empty else 0.0,
               "std_reward": float(result["reward"].std(ddof=0)) if not result.empty else 0.0,
               "cumulative_cost": float(result["cumulative_cost"].iloc[-1]) if not result.empty else 0.0,
               "negative_reward_rate": float((result["reward"] < 0).mean()) if not result.empty else 0.0,
               "n_decisions": int(len(result)), "evaluation_mode": "model_based_simulation" if transition_model is not None else "observed_transition"}
    return result, metrics


def compare_q_sarsa_baseline(panel: pd.DataFrame, q_learning, sarsa_q,
                             transition_model=None) -> tuple[pd.DataFrame, dict]:
    """Compara políticas aprendidas e baseline no mesmo holdout temporal."""
    rows = []
    for name, q in [("Q_LEARNING", q_learning), ("SARSA", sarsa_q)]:
        _, m = evaluate_policy(panel, q, transition_model=transition_model)
        rows.append({"policy": name, **m})
    # Baseline determinístico: ação 0 em todos os períodos.
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    env.reset(0); rewards=[]
    while env.i < len(panel)-1:
        _, reward, done, _ = env.step(0)
        rewards.append(reward)
        if done: break
    rows.append({
        "policy":"BASELINE_MANTER",
        "total_reward":float(np.sum(rewards)),
        "mean_reward":float(np.mean(rewards)) if rewards else 0.0,
        "std_reward":float(np.std(rewards)) if rewards else 0.0,
        "cumulative_cost":float(np.sum(np.maximum(0,-np.asarray(rewards)))) if rewards else 0.0,
        "negative_reward_rate":float(np.mean(np.asarray(rewards)<0)) if rewards else 0.0,
        "n_decisions":len(rewards),
        "evaluation_mode":"model_based_simulation",
    })
    result=pd.DataFrame(rows)
    return result, {"comparison_scope":"descriptive_model_based_simulation"}
