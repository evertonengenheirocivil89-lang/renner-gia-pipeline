import numpy as np
import pandas as pd
from src.reinforcement.environment import ACTIONS, policy_guard, reward_from_transition
from src.reinforcement.trainer import QConfig, search_configurations


def sample_panel(n=24):
    idx = pd.period_range("2020Q1", periods=n, freq="Q")
    x = np.linspace(0.01, 0.05, n)
    return pd.DataFrame({
        "revenue_growth": x,
        "net_margin": 0.06 + x,
        "ebitda_margin": 0.12 + x,
        "roic": 0.10 + x,
        "cash_revenue": 0.08 + x,
        "npl_ratio": 0.04 - x/4,
        "inventory_growth": x,
        "receivables_growth": x,
        "revenue_volatility_4q": 0.03 + x/2,
        "net_income_volatility_4q": 0.02 + x/3,
        "risk_score": 0.1,
        "climate_risk_score": 0.0,
    }, index=idx)


def test_policy_guard_restricts_investment_when_cash_low():
    row = pd.Series({"cash_revenue": 0.03, "npl_ratio": 0.02})
    assert policy_guard(5, row) == 0


def test_actions_are_discrete():
    assert len(ACTIONS) == 9


def test_reward_is_finite():
    p = sample_panel()
    r = reward_from_transition(p.iloc[0], p.iloc[1], 0)
    assert np.isfinite(r)


def test_search_is_reproducible():
    p = sample_panel()
    cfg = QConfig(episodes=20, seed=42)
    a = search_configurations(p, [cfg])[0]
    b = search_configurations(p, [cfg])[0]
    assert a["mean_tail_reward"] == b["mean_tail_reward"]


def test_transition_model_uses_only_development_panel():
    from src.reinforcement.transition_model import fit_transition_model
    p = sample_panel()
    model = fit_transition_model(p.iloc[:18])
    pred = model.predict_next(p.iloc[17])
    assert len(pred) >= 5
    assert np.isfinite(pred.to_numpy(dtype=float)).all()


def test_model_based_environment_is_flagged_as_simulated():
    from src.reinforcement.transition_model import fit_transition_model
    from src.reinforcement.environment import RennerDecisionEnv
    p = sample_panel()
    model = fit_transition_model(p.iloc[:18])
    env = RennerDecisionEnv(p.iloc[:18], transition_model=model)
    env.reset()
    _, _, _, info = env.step(0)
    assert info["simulated"] is True
