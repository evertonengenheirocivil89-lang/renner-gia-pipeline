import numpy as np
import pandas as pd

def stress_table(series, sigmas=(0.5,1.0,1.5,2.0)):
    s=pd.Series(series,dtype='float64').dropna()
    if len(s)<8: return pd.DataFrame(columns=['sigma','shock','stressed_value'])
    mu=float(s.mean()); sd=float(s.std(ddof=1))
    return pd.DataFrame([{'sigma':x,'shock':-x*sd,'stressed_value':mu-x*sd} for x in sigmas])
