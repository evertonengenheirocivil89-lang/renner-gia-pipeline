def correlation_matrix(df, columns):
    cols = [c for c in columns if c in df.columns]
    return df[cols].corr() if cols else df.iloc[:,0:0]
