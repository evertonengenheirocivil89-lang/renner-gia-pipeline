"""Camada de Engenharia de Dados inspirada no Lab01.

Fluxo didático preservado:
carregamento -> seleção -> shape/dtypes -> feature derivada -> ordenação -> visualização -> saída.
Aplicação: painel financeiro trimestral da Lojas Renner.
"""
from pathlib import Path
import json
import pandas as pd
import numpy as np


DEFAULT_COLUMNS = [
    "revenue", "net_income", "ebitda", "assets", "equity", "cash",
    "roic", "net_margin", "ebitda_margin", "cash_revenue"
]


def prepare_lab01_dataset(panel: pd.DataFrame) -> pd.DataFrame:
    """Prepara um dataset analítico equivalente ao DataFrame do Lab01."""
    df = panel.copy()
    if df.index.name is None:
        df.index.name = "period"
    df = df.reset_index()
    df["period"] = pd.to_datetime(df["period"], errors="coerce")

    # Equivalente a precos_casas = precos_casas[[...]], mas sem descartar
    # colunas que ainda podem ser necessárias ao restante do pipeline.
    selected = [c for c in DEFAULT_COLUMNS if c in df.columns]
    df = df[["period"] + selected].copy()

    numeric = [c for c in df.columns if c != "period"]
    for col in numeric:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Equivalente conceitual a Price / Area.
    # Para Renner: indicadores de intensidade econômica por base financeira.
    if {"revenue", "assets"}.issubset(df.columns):
        df["receita_por_ativo"] = df["revenue"] / df["assets"].replace(0, np.nan)
    if {"net_income", "revenue"}.issubset(df.columns):
        df["lucro_por_receita"] = df["net_income"] / df["revenue"].replace(0, np.nan)
    if {"net_income", "equity"}.issubset(df.columns):
        df["lucro_por_patrimonio"] = df["net_income"] / df["equity"].replace(0, np.nan)

    df = df.sort_values("period").reset_index(drop=True)
    return df


def profile_dataset(df: pd.DataFrame) -> dict:
    """Equivalente a shape/dtypes/head do Lab01, com qualidade adicional."""
    return {
        "shape_rows": int(df.shape[0]),
        "shape_columns": int(df.shape[1]),
        "columns": df.columns.tolist(),
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
        "missing": {c: int(v) for c, v in df.isna().sum().items()},
        "duplicates": int(df.duplicated().sum()),
        "period_min": df["period"].min().isoformat() if "period" in df and df["period"].notna().any() else None,
        "period_max": df["period"].max().isoformat() if "period" in df and df["period"].notna().any() else None,
    }


def ranking_tables(df: pd.DataFrame, n: int = 10) -> dict:
    """Equivalente aos sort_values + head do Lab01."""
    tables = {}
    if "revenue" in df:
        tables["top_revenue"] = df.sort_values("revenue", ascending=False).head(n).copy()
    if "receita_por_ativo" in df:
        tables["top_receita_por_ativo"] = df.sort_values("receita_por_ativo", ascending=False).head(n).copy()
    if "lucro_por_receita" in df:
        tables["top_lucro_por_receita"] = df.sort_values("lucro_por_receita", ascending=False).head(n).copy()
    if "roic" in df:
        tables["top_roic"] = df.sort_values("roic", ascending=False).head(n).copy()
    return tables


def build_visualizations(df: pd.DataFrame, outdir: Path, n: int = 10) -> list[str]:
    """Cria gráficos equivalentes ao Lab01 usando Matplotlib."""
    import matplotlib.pyplot as plt

    outdir.mkdir(parents=True, exist_ok=True)
    created = []

    def save_bar(frame, value_col, title, ylabel, filename):
        if frame.empty or value_col not in frame:
            return
        fig, ax = plt.subplots(figsize=(12, 6))
        labels = frame["period"].dt.strftime("%Y-%m-%d")
        ax.bar(labels, frame[value_col])
        ax.set_title(title, fontsize=15)
        ax.set_xlabel("Período", fontsize=12)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.tick_params(axis="x", rotation=45)
        fig.tight_layout()
        path = outdir / filename
        fig.savefig(path, dpi=160)
        plt.close(fig)
        created.append(str(path))

    top_revenue = df.sort_values("revenue", ascending=False).head(n) if "revenue" in df else pd.DataFrame()
    top_intensity = df.sort_values("receita_por_ativo", ascending=False).head(n) if "receita_por_ativo" in df else pd.DataFrame()
    save_bar(top_revenue, "revenue", "Top 10 períodos por receita", "Receita", "lab01_top10_receita.png")
    save_bar(top_intensity, "receita_por_ativo", "Top 10 períodos por receita/ativo", "Receita por ativo", "lab01_top10_receita_por_ativo.png")

    # Equivalente aos subplots do Lab01: comparação de duas métricas no mesmo recorte.
    if not top_revenue.empty and "lucro_por_receita" in top_revenue:
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        labels = top_revenue["period"].dt.strftime("%Y-%m-%d")
        axes[0].bar(labels, top_revenue["revenue"])
        axes[0].set_title("Top 10 períodos por receita", fontsize=15)
        axes[0].set_ylabel("Receita")
        axes[1].bar(labels, top_revenue["lucro_por_receita"])
        axes[1].set_title("Margem líquida nos mesmos períodos", fontsize=15)
        axes[1].set_ylabel("Lucro / Receita")
        for ax in axes:
            ax.tick_params(axis="x", rotation=45)
        fig.tight_layout()
        path = outdir / "lab01_subplots_receita_margem.png"
        fig.savefig(path, dpi=160)
        plt.close(fig)
        created.append(str(path))
    return created


def run_lab01_engineering(panel: pd.DataFrame, output_dir: Path) -> dict:
    """Executa a aula como uma etapa reproduzível de engenharia de dados."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    df = prepare_lab01_dataset(panel)
    profile = profile_dataset(df)
    rankings = ranking_tables(df, n=10)
    plots = build_visualizations(df, output_dir / "plots")

    df.to_csv(output_dir / "lab01_financial_dataset.csv", index=False)
    for name, table in rankings.items():
        table.to_csv(output_dir / f"{name}.csv", index=False)
    (output_dir / "lab01_profile.json").write_text(
        json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"data": df, "profile": profile, "rankings": rankings, "plots": plots}
