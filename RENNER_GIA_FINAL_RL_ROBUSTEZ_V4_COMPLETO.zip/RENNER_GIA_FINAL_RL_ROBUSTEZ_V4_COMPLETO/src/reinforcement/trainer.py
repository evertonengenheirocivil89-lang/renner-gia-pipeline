from dataclasses import dataclass
import numpy as np
import pandas as pd
from .environment import RennerDecisionEnv, ACTIONS, policy_guard

@dataclass(frozen=True)
class QConfig:
    alpha: float = 0.10
    gamma: float = 0.90
    epsilon: float = 0.20
    epsilon_decay: float = 0.995
    epsilon_min: float = 0.02
    episodes: int = 300
    bins: int = 5
    seed: int = 42


def discretize(state, bins=5):
    edges = np.asarray([-np.inf, -0.10, -0.02, 0.02, 0.10, np.inf])
    if bins != 5:
        raise ValueError("Esta implementação usa bins=5.")
    return tuple(int(np.digitize(float(x), edges) - 1) for x in state)


def _select_action(values, rng, epsilon):
    return int(rng.integers(len(ACTIONS))) if rng.random() < epsilon else int(np.argmax(values))


def train_q_learning(panel: pd.DataFrame, config: QConfig, transition_model=None):
    rng = np.random.default_rng(config.seed)
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    q, history = {}, []
    def row(state):
        key = discretize(state, config.bins)
        if key not in q:
            q[key] = np.zeros(len(ACTIONS), dtype=float)
        return q[key]
    epsilon = config.epsilon
    for ep in range(config.episodes):
        state = env.reset(0); total = 0.0; steps = 0; done = False; guard_interventions = 0
        while not done:
            values = row(state)
            raw_action = _select_action(values, rng, epsilon)
            action = policy_guard(raw_action, env.panel.iloc[env.i])
            guard_triggered = action != raw_action
            guard_interventions += int(guard_triggered)
            next_state, reward, done, _ = env.step(action)
            target = reward if done else reward + config.gamma * np.max(row(next_state))
            values[action] += config.alpha * (target - values[action])
            state = next_state; total += reward; steps += 1
        epsilon = max(config.epsilon_min, epsilon * config.epsilon_decay)
        history.append({"episode": ep + 1, "reward": total, "steps": steps, "epsilon": epsilon, "guard_interventions": guard_interventions})
    return q, pd.DataFrame(history)



def train_sarsa(panel: pd.DataFrame, config: QConfig, transition_model=None):
    """SARSA on-policy: aprende considerando a próxima ação efetivamente escolhida.
    Útil para comparar recompensa versus exposição a risco com o Q-Learning.
    """
    rng = np.random.default_rng(config.seed)
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    q, history = {}, []
    def row(state):
        key = discretize(state, config.bins)
        if key not in q:
            q[key] = np.zeros(len(ACTIONS), dtype=float)
        return q[key]
    epsilon = config.epsilon
    for ep in range(config.episodes):
        state = env.reset(0); total = 0.0; steps = 0; guard_interventions = 0
        values = row(state)
        raw_action = _select_action(values, rng, epsilon)
        action = policy_guard(raw_action, env.panel.iloc[env.i])
        guard_interventions += int(action != raw_action)
        done = False
        while not done:
            action_used = action
            next_state, reward, done, _ = env.step(action_used)
            total += reward; steps += 1
            if done:
                target = reward
            else:
                next_values = row(next_state)
                next_raw = _select_action(next_values, rng, epsilon)
                next_action = policy_guard(next_raw, env.panel.iloc[env.i])
                guard_interventions += int(next_action != next_raw)
                target = reward + config.gamma * next_values[next_action]
                action = next_action
            values[action_used] += config.alpha * (target - values[action_used])
            state = next_state
            if not done:
                values = row(state)
        epsilon = max(config.epsilon_min, epsilon * config.epsilon_decay)
        history.append({"episode": ep + 1, "reward": total, "steps": steps,
                        "epsilon": epsilon, "guard_interventions": guard_interventions})
    return q, pd.DataFrame(history)

def greedy_policy(q, state, row):
    key = discretize(state)
    values = q.get(key, np.zeros(len(ACTIONS)))
    return policy_guard(int(np.argmax(values)), row)


def run_configuration(panel, config, transition_model=None):
    q, history = train_q_learning(panel, config, transition_model=transition_model)
    tail = history.tail(max(1, min(30, len(history))))
    return {"config": config, "q": q, "history": history,
            "mean_tail_reward": float(tail["reward"].mean()),
            "std_tail_reward": float(tail["reward"].std(ddof=0)),
            "final_epsilon": float(history["epsilon"].iloc[-1]), "states": len(q)}


def search_configurations(panel, configs, transition_model=None):
    cache, results = {}, []
    for cfg in configs:
        key = (cfg.alpha, cfg.gamma, cfg.epsilon, cfg.epsilon_decay, cfg.epsilon_min, cfg.episodes, cfg.bins, cfg.seed)
        if key not in cache:
            cache[key] = run_configuration(panel, cfg, transition_model=transition_model)
        results.append(cache[key])
    return sorted(results, key=lambda r: (-r["mean_tail_reward"], r["std_tail_reward"], r["states"]))
