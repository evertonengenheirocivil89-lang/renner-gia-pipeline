from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

STATE_COLS = [
    "revenue_growth", "net_margin", "ebitda_margin", "roic",
    "cash_revenue", "npl_ratio", "inventory_growth", "receivables_growth",
    "revenue_volatility_4q", "net_income_volatility_4q", "climate_risk_score",
]

@dataclass
class TransitionModel:
    models: dict
    residual_std: dict
    feature_cols: list

    def predict_next(self, row: pd.Series) -> pd.Series:
        x = pd.DataFrame([{c: pd.to_numeric(row.get(c, np.nan), errors="coerce") for c in self.feature_cols}])
        out = {}
        for c, model in self.models.items():
            out[c] = float(model.predict(x)[0])
        return pd.Series(out)


def fit_transition_model(panel: pd.DataFrame, alpha: float = 1.0) -> TransitionModel:
    """Aprende t -> t+1 somente com o bloco fornecido (normalmente desenvolvimento).

    Não há ação histórica observada. Portanto o modelo aprende a dinâmica natural do
    negócio e a intervenção é aplicada depois como cenário limitado pela volatilidade
    residual histórica.
    """
    df = panel.sort_index().copy()
    available = [c for c in STATE_COLS if c in df.columns]
    if len(available) < 5:
        raise ValueError("Poucas variáveis disponíveis para o modelo de transição.")
    X = df[available].apply(pd.to_numeric, errors="coerce").iloc[:-1]
    Y = df[available].apply(pd.to_numeric, errors="coerce").shift(-1).iloc[:-1]
    models, residual_std = {}, {}
    for target in available:
        valid = Y[target].notna()
        if valid.sum() < max(12, len(available) + 3):
            continue
        model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("ridge", Ridge(alpha=alpha)),
        ])
        model.fit(X.loc[valid], Y.loc[valid, target])
        pred = model.predict(X.loc[valid])
        residual_std[target] = float(np.nanstd(Y.loc[valid, target].to_numpy() - pred))
        models[target] = model
    if not models:
        raise ValueError("Não foi possível ajustar nenhum componente da transição.")
    return TransitionModel(models=models, residual_std=residual_std, feature_cols=available)
