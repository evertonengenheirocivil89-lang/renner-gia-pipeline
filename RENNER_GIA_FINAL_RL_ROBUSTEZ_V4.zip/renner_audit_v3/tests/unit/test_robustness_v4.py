import numpy as np
import pandas as pd
from src.reinforcement.environment import build_state
from src.reinforcement.transition_model import fit_transition_model
from src.reinforcement.trainer import QConfig, train_q_learning, train_sarsa
from src.reinforcement.evaluation import compare_q_sarsa_baseline


def make_panel(n=24):
    idx = pd.date_range('2020-03-31', periods=n, freq='QE')
    x = np.arange(n, dtype=float)
    return pd.DataFrame({
        'revenue_growth': 0.02 + 0.001*x,
        'net_margin': 0.08 + 0.0005*x,
        'ebitda_margin': 0.12 + 0.0003*x,
        'roic': 0.14 + 0.0002*x,
        'cash_revenue': 0.10 + 0.001*x,
        'npl_ratio': 0.04 + 0.0005*x,
        'inventory_growth': 0.01 + 0.001*x,
        'receivables_growth': 0.01 + 0.0008*x,
        'revenue_volatility_4q': 0.03 + 0.0001*x,
        'net_income_volatility_4q': 0.04 + 0.0001*x,
        'climate_risk_score': 0.10 + 0.001*x,
    }, index=idx)


def test_missingness_is_explicit_in_state():
    row = pd.Series({'revenue_growth': np.nan, 'net_margin': 0.1})
    state = build_state(row)
    assert len(state) == 22
    assert state[0] == 0.0
    assert state[11] == 1.0
    assert state[12] == 0.0


def test_transition_sigma_is_finite_and_oos_calibrated():
    panel = make_panel()
    tm = fit_transition_model(panel.iloc[:20])
    assert tm.models
    assert all(np.isfinite(v) and v >= 0 for v in tm.residual_std.values())


def test_q_sarsa_baseline_comparison_is_comparable():
    panel = make_panel()
    dev, test = panel.iloc[:18], panel.iloc[18:]
    tm = fit_transition_model(dev)
    cfg = QConfig(alpha=.05, gamma=.8, epsilon=.1, episodes=8, seed=7)
    q, _ = train_q_learning(dev, cfg, transition_model=tm)
    s, _ = train_sarsa(dev, cfg, transition_model=tm)
    result, meta = compare_q_sarsa_baseline(test, q, s, transition_model=tm)
    assert set(result['policy']) == {'Q_LEARNING', 'SARSA', 'BASELINE_MANTER'}
    assert meta['comparison_scope'] == 'descriptive_model_based_simulation'
