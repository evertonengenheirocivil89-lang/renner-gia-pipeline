import numpy as np

def add_temporal_features(df):
    out = df.copy().sort_index()
    for c in ["revenue", "net_income", "ebitda", "roic"]:
        if c in out.columns:
            out[f"{c}_growth_yoy"] = out[c].pct_change(4, fill_method=None)
            out[f"{c}_volatility_4q"] = out[c].pct_change(fill_method=None).rolling(4).std()
    out["quarter"] = out.index.quarter if hasattr(out.index, "quarter") else np.nan
    return out
