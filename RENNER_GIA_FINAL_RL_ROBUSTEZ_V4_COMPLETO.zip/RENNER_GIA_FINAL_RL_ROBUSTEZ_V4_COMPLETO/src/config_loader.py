import json
from pathlib import Path

def load_settings(path):
    path = Path(path)
    with path.open(encoding="utf-8") as f:
        return json.load(f)
