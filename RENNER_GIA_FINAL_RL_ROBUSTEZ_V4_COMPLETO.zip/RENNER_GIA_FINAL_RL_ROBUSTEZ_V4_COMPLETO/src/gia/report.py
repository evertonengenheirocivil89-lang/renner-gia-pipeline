from pathlib import Path
import pandas as pd

def _fmt(name, x):
    if pd.isna(x): return "N/D"
    if name in {"net_margin","ebitda_margin","roic","revenue_growth","npl_ratio"}:
        return f"{x*100:.1f}%"
    return f"{x:,.2f}"

def build_report(analysis, alerts, forecast_text, esg_status, output, climate_risks=None, emissions=None, climate_targets=None, climate_opportunities=None, rl_metrics=None, rl_results=None, rl_baseline_metrics=None, rl_comparison=None):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Relatório Executivo — Renner GIA — Versão Final — Decision Intelligence",
        "",
        "## 1. Arquitetura",
        "RAW → INGESTÃO → QUALIDADE → FILTRAGEM → NORMALIZAÇÃO ESTRUTURAL → DATA MART → FEATURES → FORECAST → ESG/CLIMA → ALERTAS → GIA.",
        "",
        "## 2. Indicadores avançados",
    ]
    if not analysis.empty:
        last = analysis.sort_index().iloc[-1]
        for c in ["revenue_growth","ebitda_margin","net_margin","roic","debt_ebitda","current_ratio","quick_ratio","assets_equity","cash_to_revenue"]:
            if c in analysis.columns:
                lines.append(f"- **{c}**: {_fmt(c, last[c])}")
    lines += [
        "", "## 3. Tendência e volatilidade",
        "As médias móveis e a volatilidade são calculadas sobre a série trimestral standalone produzida pela camada financeira, evitando misturar períodos acumulados com trimestres.",
        "", "## 4. Alertas GIA"
    ]
    if alerts.empty:
        lines.append("- Nenhum indicador com regra aplicável.")
    else:
        latest_period = alerts["period"].max()
        for _, r in alerts[alerts["period"] == latest_period].iterrows():
            lines.append(f"- **{r['indicator']}**: {r['status']} | valor={r['value']:.4f}")
    lines += [
        "", "## 5. Previsão", forecast_text,
        "", "A previsão ARIMA é exploratória. O pacote final inclui validação temporal walk-forward para avaliação de modelos; previsões continuam condicionadas à qualidade e disponibilidade histórica dos dados.",
        "", "## 6. ESG e clima — IFRS S1/S2 e CBPS 1/2",
        "O relatório 2025 passa a ser uma fonte estruturada do GIA. Os dados abaixo são transcritos/estruturados da divulgação fornecida e não representam um score ESG criado pelo modelo."
    ]
    if climate_risks is not None and not climate_risks.empty:
        lines.append("### 6.1 Riscos climáticos")
        for _, r in climate_risks.iterrows():
            impact = "N/D" if pd.isna(r.get("financial_impact_2025_result_m")) else f"R$ {r['financial_impact_2025_result_m']:.1f} mi"
            future = "N/D" if pd.isna(r.get("future_cf_high_m")) else f"até R$ {r['future_cf_high_m']:.1f} mi"
            lines.append(f"- **{r['risk']}** — impacto operacional 2025: {impact}; fluxo de caixa futuro: {future}; status: {r['status_2025']}.")
    if emissions is not None and not emissions.empty:
        lines.append("### 6.2 Inventário de emissões 2025")
        for _, r in emissions.iterrows():
            lines.append(f"- {r['scope']} ({r['category']}): {r['tco2e']:,.2f} tCO2e.")
    if climate_targets is not None and not climate_targets.empty:
        lines.append("### 6.3 Metas climáticas")
        for _, r in climate_targets.iterrows():
            lines.append(f"- {r['target']}: redução de {r['target_reduction_pct']:.1f}% até {int(r['target_year'])}; status 2025: {r['status_2025']}.")
    if rl_metrics:
        lines.append("### 7.1 Avaliação temporal da política")
        lines.append(f"- Decisões avaliadas: {int(rl_metrics.get('n_decisions', 0))}.")
        lines.append(f"- Recompensa média: {float(rl_metrics.get('mean_reward', 0.0)):.4f}.")
        lines.append(f"- Recompensa acumulada: {float(rl_metrics.get('total_reward', 0.0)):.4f}.")
        lines.append("- A política possui guarda de governança para limitar ações incompatíveis com níveis críticos de caixa/NPL.")
        if rl_baseline_metrics:
            lines.append(f"- Política-base MANTER_ESTRATEGIA: recompensa média {float(rl_baseline_metrics.get('mean_reward', 0.0)):.4f}; custo acumulado {float(rl_baseline_metrics.get('cumulative_cost', 0.0)):.4f}.")
        if rl_comparison:
            lines.append("- A comparação com a política-base é descritiva dentro da simulação; não representa efeito causal observado.")
            lines.append(f"- Trocas de ação: {float(rl_metrics.get('policy_action_switch_rate', 0.0))*100:.1f}% das decisões; intervenções da guarda: {int(rl_metrics.get('policy_guard_interventions', 0))}.")
        if rl_metrics.get("uncertainty_mc_n_simulations"):
            lines.append("### 7.2 Incerteza e estabilidade da política")
            lines.append(f"- Monte Carlo: {int(rl_metrics.get('uncertainty_mc_n_simulations'))} trajetórias simuladas usando a distribuição residual do modelo de transição.")
            lines.append(f"- Recompensa acumulada simulada — média: {float(rl_metrics.get('uncertainty_mc_total_reward_mean', 0.0)):.4f}; P05: {float(rl_metrics.get('uncertainty_mc_total_reward_p05', 0.0)):.4f}; P95: {float(rl_metrics.get('uncertainty_mc_total_reward_p95', 0.0)):.4f}.")
            lines.append(f"- Estabilidade entre sementes: média da recompensa final {float(rl_metrics.get('uncertainty_seed_mean_tail_reward', 0.0)):.4f}; IC95% aproximado [{float(rl_metrics.get('uncertainty_seed_ci95_low', 0.0)):.4f}, {float(rl_metrics.get('uncertainty_seed_ci95_high', 0.0)):.4f}] em {int(rl_metrics.get('uncertainty_n_training_seeds', 0))} sementes.")
            lines.append("- Esses intervalos quantificam incerteza de simulação/estabilidade do treinamento; não são intervalos de efeito causal ou de previsão financeira da empresa.")
    lines += [
        "", "## 7. Aprendizagem por reforço",
        "A camada RL segue o princípio de seleção temporal: hiperparâmetros são escolhidos somente no bloco de desenvolvimento e o bloco temporal final é reservado para avaliação. Como o histórico financeiro não identifica explicitamente a ação gerencial tomada em cada trimestre, os efeitos das ações são tratados como cenários parametrizados, não como causalidade observada.",
        "", "## 8. Benchmarking",
        "O pipeline permanece preparado para C&A, Riachuelo e Arezzo. Nenhum valor de concorrente é estimado sem fonte oficial comparável.",
        "", "## 9. GIA",
        "- **Governance:** rastreabilidade da fonte, qualidade dos dados e conexão com materialidade e governança de riscos.",
        "- **Intelligence:** indicadores financeiros + riscos climáticos + emissões + metas + previsões.",
        "- **Action:** alertas separados entre risco financeiro observado, risco projetado e monitoramento qualitativo.",
        "", "## 10. Governança técnica e limitações",
        "- O RI da Renner está configurado como fonte oficial, mas o catálogo somente registra arquivos efetivamente disponíveis localmente; não é declarada uma coleta online quando ela não ocorreu.",
        "- Valores ESG não disponíveis permanecem como N/D; o sistema não cria score ESG sintético.",
        "- Benchmarking de concorrentes permanece sem valores estimados quando não há fonte oficial comparável.",
        "- Logs estruturados e testes automatizados acompanham a execução do pipeline.",
        "", "## 11. Pontos de evolução",
        "1. Integrar dados temporais de clima, lojas e geografia para modelar riscos físicos.",
        "2. Conectar risco climático a receita, estoque, markdown, margem e fluxo de caixa.",
        "3. Incorporar métricas sociais e de governança quando os dados estruturados estiverem disponíveis.",
        "4. Integrar pares somente com bases oficiais e métricas metodologicamente comparáveis.",
        "5. Evoluir a explicabilidade dos modelos com SHAP/LIME após estabilização das variáveis de entrada.",
        ""
    ]
    output.write_text("\n".join(lines), encoding="utf-8")
    return output
