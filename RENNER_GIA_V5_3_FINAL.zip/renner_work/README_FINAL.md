# RENNER GIA — V5.3

Pipeline de Decision Intelligence para análise financeira, crédito, operação, ESG/clima e GIA, com validação temporal, forecast comparativo e RL model-based.

## Fluxo
RAW → INGESTÃO → QUALIDADE → ENGENHARIA → DATA MARTS → FEATURES → FORECAST → RISCO → ESG/CLIMA → TRANSITION MODEL → RL → INCERTEZA → GIA → RELATÓRIO.

## Principais melhorias V5.3
- Forecast temporal comparativo: baseline ingênuo × ARIMA × Ridge.
- Métricas comuns: MAE, RMSE, sMAPE, Bias e N.
- Validação walk-forward sem uso de dados futuros.
- Estado RL com valor substituto + indicador explícito de missingness.
- Pré-cálculo das transições para reduzir custo do treinamento.
- Busca de hiperparâmetros separada do treino final.
- Treino final, holdout temporal, baseline, diagnóstico, multi-seed e Monte Carlo em etapas observáveis.
- Monte Carlo com 250 simulações e resíduos do modelo de transição.
- Limiares e parâmetros principais em `config/settings.json`.
- Logs estruturados JSONL com `run_id`, estágio, duração e status.

## Execução
```bash
python -m pytest -q
python main.py
```

## Validação desta entrega
- `python -m compileall -q src main.py`: OK
- `pytest -q`: 28 passed
- execução ponta a ponta: 29/29 etapas SUCCESS
- tempo de pipeline observado: 25,16 s
- sem FAILED e sem FALLBACK na execução validada

## Entregáveis
- `outputs/Relatorio_Executivo_Renner_GIA_FINAL.md`
- `outputs/renner_gia_FINAL_analysis.xlsx`
- `outputs/run_manifest.json`
- `logs/pipeline.jsonl`
- `data/processed/forecast_model_metrics.csv`
- `data/processed/forecast_model_predictions.csv`
- `data/processed/rl_baseline_metrics.csv`
- `data/processed/rl_policy_vs_baseline.csv`
- `data/processed/rl_seed_stability.csv`
- `data/processed/rl_monte_carlo.csv`
- `data/processed/rl_uncertainty_metrics.csv`

## Fontes e integridade
- Workbook financeiro fornecido para o projeto.
- Relatório IFRS S1/S2 / CBPS 1 e 2 fornecido.
- RI Lojas Renner configurado como fonte oficial para catalogação; esta versão não declara download online quando os arquivos não estão disponíveis localmente.
- `ND` permanece como ausência de dado.
- Não há score ESG sintético.
- Não há valores estimados de concorrentes sem fonte comparável.
- Modelos usam validação temporal; não há divisão aleatória para séries temporais.
- Indicadores são calculados somente quando seus componentes existem.
- O RL é uma simulação model-based; não representa evidência causal nem ações históricas observadas.
- O baseline é preservado para comparação e não é tratado como inferior/superior por regra.

## Dependências
`statsmodels` é necessária porque `src/models/forecast_advanced.py` utiliza ARIMA. `python-docx` não é dependência desta versão.
