# Auditoria RL + Cenário Desfavorável — Renner

## 1. Testes

- Testes automatizados após as atualizações: **25 passed**.
- Foram adicionados testes para o cenário de estresse e mantida a cobertura da camada de incerteza.
- O cálculo de Monte Carlo/estresse foi otimizado para reutilizar previsões determinísticas por período e reamostrar apenas os resíduos.

## 2. Configuração avaliada

Bloco de desenvolvimento: 68 períodos. Holdout temporal: 18 períodos; 17 decisões efetivas.

- Q-Learning: alpha=0.05, gamma=0.80, epsilon=0.10
- epsilon_decay=0.995; epsilon_min=0.02
- episódios=80; bins=5; seed=42
- Monte Carlo: 250 trajetórias
- sementes de estabilidade: 11, 22, 33

## 3. Resultado do holdout

| Métrica | RL | Política-base |
|---|---:|---:|
| Recompensa acumulada | 0.3100 | 0.3785 |
| Recompensa média | 0.0182 | 0.0223 |
| Custo acumulado | 0.0673 | 0.0466 |
| Taxa de recompensa negativa | 35.3% | 35.3% |
| Trocas de ação | 10 | 0 |

A comparação é **descritiva e model-based**. Não representa efeito causal observado.

## 4. Estabilidade do treinamento

Com seeds 11, 22 e 33, a recompensa média dos 30 episódios finais foi:

- seed 11: -0.0827
- seed 22: -0.0761
- seed 33: -0.0524
- média: aproximadamente -0.0704
- IC95% aproximado: [-0.0885; -0.0523]

Esse resultado merece atenção: a recompensa de treinamento final permanece negativa, enquanto o holdout temporal apresenta recompensa positiva. Isso indica sensibilidade entre treinamento e avaliação e recomenda não interpretar o valor positivo do holdout como evidência de superioridade do RL.

## 5. Monte Carlo neutro

250 trajetórias usando a distribuição residual do modelo de transição:

- recompensa acumulada média: 0.2948
- P05: -0.0168
- mediana: 0.2987
- P95: 0.5913
- custo acumulado médio: 0.2170
- custo acumulado P95: 0.3806

Portanto, mesmo sem estresse adverso, uma parcela das trajetórias simuladas apresenta recompensa acumulada negativa.

## 6. Cenário desfavorável

O estresse desloca os resíduos em direção adversa por 0,5; 1,0; 1,5 e 2,0 desvios-padrão. Para variáveis favoráveis, o choque é negativo; para volatilidade/risco, positivo. O componente aleatório normal continua sendo amostrado.

| Choque adverso | Recompensa média RL | P05 | P95 | Custo médio |
|---:|---:|---:|---:|---:|
| 0,5 sigma | -0.2032 | -0.4652 | 0.0453 | 0.4524 |
| 1,0 sigma | -0.7089 | -0.9709 | -0.4604 | 0.8098 |
| 1,5 sigma | -1.2146 | -1.4766 | -0.9661 | 1.2475 |
| 2,0 sigma | -1.7203 | -1.9823 | -1.4718 | 1.7282 |

A política-base também deteriora sob o mesmo estresse, mas permanece numericamente acima do RL neste simulador:

| Choque | Recompensa média base |
|---:|---:|
| 0,5 sigma | -0.1347 |
| 1,0 sigma | -0.6404 |
| 1,5 sigma | -1.1461 |
| 2,0 sigma | -1.6518 |

## 7. Possíveis problemas / limitações identificados

### 7.1 Efeitos das ações não são observados
As ações do ambiente são intervenções hipotéticas. Como o histórico não contém a ação gerencial efetivamente tomada em cada trimestre, os efeitos não podem ser interpretados como causais.

### 7.2 Resíduos usados no Monte Carlo
A incerteza é baseada no desvio dos resíduos do ajuste do modelo de transição. Isso não captura necessariamente autocorrelação, heterocedasticidade ou mudanças estruturais.

### 7.3 Apenas três seeds
Um IC95% baseado em apenas três sementes é diagnóstico, não uma estimativa estatística robusta. Mais seeds seriam necessárias para uma avaliação de estabilidade mais forte.

### 7.4 Variáveis ausentes
`build_state()` transforma valores ausentes em 0. Isso evita quebra do RL, mas pode confundir ausência de informação com valor neutro. O ideal para uma versão futura é adicionar indicadores explícitos de missingness.

### 7.5 Guarda de governança
A guarda é simples e baseada em thresholds de caixa/NPL. Ela não representa toda a política de risco da empresa.

### 7.6 Modelo de transição
O Ridge é adequado como baseline transparente para o pequeno número de observações, mas não deve ser interpretado como modelo causal do negócio.

### 7.7 Resultado do holdout
A política-base supera a política RL no holdout simulado e também apresenta menor custo acumulado. Isso deve ser mantido como resultado do experimento, sem seleção posterior de métricas para favorecer o RL.

## 8. Leitura do cenário desfavorável

O cenário de 1 sigma já leva a recompensa média simulada do RL para aproximadamente -0,71 e custo acumulado médio para aproximadamente 0,81. Em 2 sigma, a recompensa média chega a aproximadamente -1,72.

Esses valores **não são perdas financeiras em reais**. São unidades da função de recompensa do ambiente. O cenário deve ser usado para testar robustez, limites e necessidade de controles adicionais, não como previsão financeira.

## 9. Próxima melhoria técnica recomendada

Antes de aumentar a complexidade do algoritmo RL, a próxima evolução deve ser:

1. incluir indicadores de missingness no estado;
2. estimar resíduos out-of-sample para a incerteza;
3. aumentar o número de seeds;
4. testar resíduos bootstrapados ou blocos temporais, além da normalidade;
5. comparar Q-Learning, SARSA e política-base sob exatamente os mesmos cenários;
6. somente depois avaliar algoritmos mais complexos.
