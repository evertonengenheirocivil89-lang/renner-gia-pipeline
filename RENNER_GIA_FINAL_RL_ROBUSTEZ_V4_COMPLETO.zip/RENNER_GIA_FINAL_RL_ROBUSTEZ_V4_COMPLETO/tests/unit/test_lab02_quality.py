import pandas as pd
from pathlib import Path
from src.etl.lab02_quality import clean_financial_dataset, detect_outliers_iqr


def test_lab02_does_not_convert_missing_to_zero():
    df = pd.DataFrame({
        "period": pd.to_datetime(["2025-03-31", "2025-06-30"]),
        "revenue": [100.0, None],
        "net_income": [10.0, 5.0],
        "assets": [500.0, 510.0],
        "equity": [200.0, 205.0],
    })
    clean, report = clean_financial_dataset(df)
    assert pd.isna(clean.loc[1, "revenue"])
    assert report["imputation_performed"] is False


def test_lab02_removes_exact_duplicates_and_keeps_period_order():
    df = pd.DataFrame({
        "period": pd.to_datetime(["2025-06-30", "2025-03-31", "2025-03-31"]),
        "revenue": [110.0, 100.0, 100.0],
    })
    clean, _ = clean_financial_dataset(df)
    assert clean["period"].is_monotonic_increasing
    assert len(clean) == 2


def test_lab02_marks_outlier_without_deleting_row():
    df = pd.DataFrame({"revenue": [100, 101, 99, 100, 1000]})
    out = detect_outliers_iqr(df, ["revenue"])
    assert len(out) == 5
    assert bool(out.loc[4, "flag_outlier_revenue"])
