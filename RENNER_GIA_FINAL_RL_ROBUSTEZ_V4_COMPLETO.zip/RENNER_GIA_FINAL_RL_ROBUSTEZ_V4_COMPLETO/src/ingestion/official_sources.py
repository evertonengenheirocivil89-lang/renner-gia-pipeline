from pathlib import Path
import pandas as pd
import hashlib

OFFICIAL_ROOTS = {
    "RI": "https://ri.lojasrenner.com.br/",
    "CVM": "https://www.gov.br/cvm/pt-br",
}
SUPPORTED = {".xlsx", ".xls", ".csv", ".pdf", ".zip", ".json"}

def inventory_official_sources(raw_dir):
    raw = Path(raw_dir)
    rows = []
    for source in ("RI", "CVM", "ESG"):
        folder = raw / source
        folder.mkdir(parents=True, exist_ok=True)
        for p in sorted(folder.rglob("*")):
            if p.is_file() and p.suffix.lower() in SUPPORTED:
                rows.append({
                    "source": source,
                    "file": p.name,
                    "path": str(p),
                    "extension": p.suffix.lower(),
                    "size_bytes": p.stat().st_size,
                    "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                    "official_source_base": OFFICIAL_ROOTS.get(source, "documento ESG armazenado"),
                    "status": "local_file_available",
                })
    return pd.DataFrame(rows)

def source_register(raw_dir):
    inv = inventory_official_sources(raw_dir)
    if inv.empty:
        return inv
    inv["source_role"] = inv["source"].map({
        "RI": "public company investor-relations source",
        "CVM": "regulatory/public filing source",
        "ESG": "ESG/governance documentary evidence",
    })
    return inv
