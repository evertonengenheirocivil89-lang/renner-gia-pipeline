import pandas as pd


def build_credit_panel(frames):
    parts = []
    for key in ['accounts_receivables', 'credit_losses', 'npl', 'receivables_bacen', 'financial_services']:
        df = frames.get(key, pd.DataFrame()).copy()
        if not df.empty:
            df['dataset'] = key
            parts.append(df)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
