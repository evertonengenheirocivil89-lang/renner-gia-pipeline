import pandas as pd
from src.periods import period_kind


def _metric(df, names):
    if df.empty:
        return pd.DataFrame(columns=['period','value','metric','period_label'])
    wanted = {str(x).strip().casefold() for x in names}
    x = df[df.metric.str.strip().str.casefold().isin(wanted)].copy()
    return x[['period','value','metric','period_label']].sort_values(['period','period_label'])


def _series(frames, key, names):
    x = _metric(frames.get(key, pd.DataFrame()), names)
    if x.empty:
        return x
    # For flow statements, standalone quarters are preferred. Accumulated
    # periods are retained only when no quarterly observation exists.
    if key in {'income_statement','cash_flow','financial_services','ebitda','ebitda_ex_ifrs16','capex'}:
        kinds = x['period_label'].map(period_kind)
        q = x[kinds.eq('quarter')]
        if not q.empty:
            x = q
    # Multiple representations can map to the same quarter. Keep the last
    # explicitly ordered observation rather than inventing a value.
    return x.drop_duplicates('period', keep='last')


def build_financial_panel(frames, target_metrics):
    series = {}
    provenance = {}
    preferred_order = [
        ('revenue', ['income_statement', 'financial_services']),
        ('net_income', ['income_statement', 'cash_flow', 'ebitda']),
        ('ebitda', ['ebitda', 'ebitda_ex_ifrs16']),
        ('assets', ['balance_sheet']),
        ('equity', ['balance_sheet']),
        ('cash', ['balance_sheet']),
    ]
    for name, keys in preferred_order:
        names = target_metrics.get(name, [])
        for key in keys:
            s = _series(frames, key, names)
            if not s.empty:
                series[name] = s.set_index('period')['value']
                provenance[name] = key
                break
    panel = pd.DataFrame(series).sort_index()
    panel.attrs['provenance'] = provenance
    return panel
