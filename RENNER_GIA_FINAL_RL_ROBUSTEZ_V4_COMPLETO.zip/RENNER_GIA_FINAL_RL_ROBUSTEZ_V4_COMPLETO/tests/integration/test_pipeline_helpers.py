from pathlib import Path
from src.ingestion.ri_renner import build_ri_manifest

def test_ri_catalog_does_not_claim_online_download(tmp_path):
    raw = tmp_path / "raw"
    (raw / "RI").mkdir(parents=True)
    (raw / "RI" / "Resultado_1T2025.pdf").write_bytes(b"test")
    out = tmp_path / "manifest.csv"
    catalog, meta = build_ri_manifest(raw, out)
    assert len(catalog) == 1
    assert meta["online_download_attempted"] is False
    assert out.exists()
