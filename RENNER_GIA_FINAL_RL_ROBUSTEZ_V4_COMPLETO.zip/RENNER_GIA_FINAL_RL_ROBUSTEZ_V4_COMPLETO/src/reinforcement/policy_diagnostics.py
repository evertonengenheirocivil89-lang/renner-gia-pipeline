"""Diagnósticos de política inspirados nos Labs de RL.

Adapta para a Renner três ideias úteis dos exercícios:
1) custo/recompensa acumulada;
2) comparação com uma política-base;
3) estabilidade da política e intervenções da governança.

Não interpreta o resultado como causalidade nem como recomendação empresarial.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .environment import ACTIONS, RennerDecisionEnv, build_state, policy_guard
from .trainer import greedy_policy


def evaluate_baseline(panel: pd.DataFrame, transition_model=None, action: int = 0):
    """Avalia uma política simples e explícita; por padrão, MANTER_ESTRATEGIA."""
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    env.reset(0)
    rows = []
    total = 0.0
    cumulative_cost = 0.0
    while env.i < len(env.panel) - 1:
        current = env.panel.iloc[env.i]
        safe_action = policy_guard(action, current)
        _, reward, done, info = env.step(safe_action)
        total += reward
        cumulative_cost += max(0.0, -reward)
        rows.append({
            "period": info.get("period"),
            "action_id": safe_action,
            "action": ACTIONS[safe_action],
            "reward": reward,
            "cumulative_reward": total,
            "cumulative_cost": cumulative_cost,
            "simulated": info.get("simulated", False),
        })
        if done:
            break
    result = pd.DataFrame(rows)
    return result, _summary(result, "baseline")


def _summary(result: pd.DataFrame, policy_type: str) -> dict:
    if result.empty:
        return {"policy_type": policy_type, "n_decisions": 0}
    actions = result["action_id"].astype(int)
    switches = int((actions.diff().fillna(0) != 0).sum())
    return {
        "policy_type": policy_type,
        "n_decisions": int(len(result)),
        "total_reward": float(result["reward"].sum()),
        "mean_reward": float(result["reward"].mean()),
        "cumulative_cost": float(result["cumulative_cost"].iloc[-1]),
        "negative_reward_rate": float((result["reward"] < 0).mean()),
        "action_switches": switches,
        "action_switch_rate": float(switches / max(1, len(result) - 1)),
        "unique_actions": int(actions.nunique()),
    }


def evaluate_rl_with_diagnostics(panel, q, transition_model=None):
    """Executa a política gulosa e retorna série + diagnóstico de estabilidade."""
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    env.reset(0)
    rows = []
    raw_actions = []
    guarded_actions = []
    total = 0.0
    cumulative_cost = 0.0
    while env.i < len(env.panel) - 1:
        current = env.panel.iloc[env.i]
        raw = greedy_policy(q, build_state(current), current)
        guarded = policy_guard(raw, current)
        raw_actions.append(int(raw)); guarded_actions.append(int(guarded))
        _, reward, done, info = env.step(guarded)
        total += reward
        cumulative_cost += max(0.0, -reward)
        rows.append({
            "period": info.get("period"),
            "raw_action_id": int(raw),
            "action_id": int(guarded),
            "action": ACTIONS[int(guarded)],
            "reward": reward,
            "cumulative_reward": total,
            "cumulative_cost": cumulative_cost,
            "guard_intervention": int(raw != guarded),
            "simulated": info.get("simulated", False),
        })
        if done:
            break
    result = pd.DataFrame(rows)
    metrics = _summary(result.rename(columns={}), "rl")
    metrics["guard_interventions"] = int(sum(a != b for a, b in zip(raw_actions, guarded_actions)))
    metrics["guard_intervention_rate"] = float(metrics["guard_interventions"] / max(1, len(raw_actions)))
    return result, metrics


def compare_policy_to_baseline(rl_result: pd.DataFrame, baseline_result: pd.DataFrame) -> dict:
    """Compara métricas descritivas; não estima efeito causal."""
    def total(df, col):
        return float(df[col].iloc[-1]) if not df.empty and col in df else np.nan
    return {
        "rl_total_reward": total(rl_result, "cumulative_reward"),
        "baseline_total_reward": total(baseline_result, "cumulative_reward"),
        "rl_cumulative_cost": total(rl_result, "cumulative_cost"),
        "baseline_cumulative_cost": total(baseline_result, "cumulative_cost"),
        "comparison_scope": "descriptive_model_based_simulation",
    }
