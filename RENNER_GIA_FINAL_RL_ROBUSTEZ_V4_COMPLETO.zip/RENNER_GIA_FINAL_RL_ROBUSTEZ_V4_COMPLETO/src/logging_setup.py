import json, logging
from pathlib import Path
from datetime import datetime, timezone

class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "stage": getattr(record, "stage", "general"),
            "message": record.getMessage(),
        }
        return json.dumps(payload, ensure_ascii=False)

def setup_logging(log_dir):
    log_dir = Path(log_dir); log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("renner_gia")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    handler = logging.FileHandler(log_dir / "pipeline.jsonl", encoding="utf-8")
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("%(levelname)s | %(message)s"))
    logger.addHandler(console)
    return logger
