import numpy as np
import pandas as pd

def add_advanced_indicators(df):
    out = df.copy().sort_index()
    if {"ebitda","revenue"}.issubset(out.columns):
        out["ebitda_margin"] = out["ebitda"] / out["revenue"].replace(0, np.nan)
    if {"net_income","revenue"}.issubset(out.columns):
        out["net_margin"] = out["net_income"] / out["revenue"].replace(0, np.nan)
    if {"assets","equity"}.issubset(out.columns):
        out["assets_equity"] = out["assets"] / out["equity"].replace(0, np.nan)
    if {"cash","revenue"}.issubset(out.columns):
        out["cash_to_revenue"] = out["cash"] / out["revenue"].replace(0, np.nan)
    # Only calculate these when the actual components exist; no proxy is silently renamed as Debt/EBITDA.
    if {"total_debt","ebitda_ltm"}.issubset(out.columns):
        out["debt_ebitda"] = out["total_debt"] / out["ebitda_ltm"].replace(0, np.nan)
    if {"current_assets","current_liabilities"}.issubset(out.columns):
        out["current_ratio"] = out["current_assets"] / out["current_liabilities"].replace(0, np.nan)
    if {"current_assets","inventory","current_liabilities"}.issubset(out.columns):
        out["quick_ratio"] = (out["current_assets"] - out["inventory"]) / out["current_liabilities"].replace(0, np.nan)
    return out
