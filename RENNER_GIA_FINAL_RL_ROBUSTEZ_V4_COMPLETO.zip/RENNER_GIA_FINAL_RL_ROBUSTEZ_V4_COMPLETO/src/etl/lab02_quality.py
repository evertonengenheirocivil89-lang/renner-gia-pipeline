"""Lab02 — Qualidade e tratamento do dataset financeiro.

Princípios:
- não transforma ND em zero;
- não preenche faltantes financeiros automaticamente;
- registra cada tratamento realizado;
- remove apenas duplicidades exatas/temporais explicitamente definidas;
- cria flags de qualidade para que ML/RL possa conhecer a disponibilidade dos dados.
"""
from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd


NUMERIC_CANDIDATES = [
    "revenue", "net_income", "ebitda", "assets", "equity", "cash",
    "roic", "net_margin", "ebitda_margin", "cash_revenue",
    "receita_por_ativo", "lucro_por_receita", "lucro_por_patrimonio",
]


def audit_dataset(df: pd.DataFrame) -> dict:
    """Produz auditoria antes do tratamento."""
    numeric = [c for c in NUMERIC_CANDIDATES if c in df.columns]
    return {
        "rows_before": int(len(df)),
        "columns": int(len(df.columns)),
        "duplicate_rows": int(df.duplicated().sum()),
        "duplicate_periods": int(df["period"].duplicated().sum()) if "period" in df else 0,
        "invalid_periods": int(df["period"].isna().sum()) if "period" in df else 0,
        "missing_by_column": {c: int(df[c].isna().sum()) for c in numeric},
        "negative_revenue": int((df["revenue"] < 0).sum()) if "revenue" in df else 0,
        "zero_denominators": {
            c: int((df[c] == 0).sum()) for c in ["revenue", "assets", "equity"] if c in df
        },
    }


def clean_financial_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Limpa estrutura sem inventar valores financeiros."""
    out = df.copy()
    report: dict = {"actions": []}

    if "period" in out.columns:
        out["period"] = pd.to_datetime(out["period"], errors="coerce")
        invalid = int(out["period"].isna().sum())
        if invalid:
            out = out.loc[out["period"].notna()].copy()
            report["actions"].append({"action": "remove_invalid_period", "rows": invalid})

    numeric = [c for c in NUMERIC_CANDIDATES if c in out.columns]
    for col in numeric:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    exact_before = len(out)
    out = out.drop_duplicates().copy()
    exact_removed = exact_before - len(out)
    if exact_removed:
        report["actions"].append({"action": "remove_exact_duplicates", "rows": exact_removed})

    # Um período deve representar uma observação financeira única neste painel.
    # Em caso de duplicidade, mantemos a primeira e registramos o tratamento.
    if "period" in out.columns:
        dup_period = int(out["period"].duplicated(keep="first").sum())
        if dup_period:
            out = out.drop_duplicates(subset=["period"], keep="first").copy()
            report["actions"].append({"action": "deduplicate_period", "rows": dup_period})
        out = out.sort_values("period").reset_index(drop=True)

    # Flags de disponibilidade. Não há imputação automática.
    available_cols = [c for c in ["revenue", "net_income", "ebitda", "assets", "equity", "cash"] if c in out]
    if available_cols:
        out["data_completeness_ratio"] = out[available_cols].notna().mean(axis=1)
        out["financial_data_complete"] = out[available_cols].notna().all(axis=1)

    # Flags de valores potencialmente problemáticos, sem removê-los automaticamente.
    if "revenue" in out:
        out["flag_revenue_negative"] = out["revenue"].lt(0).fillna(False)
        out["flag_revenue_zero"] = out["revenue"].eq(0).fillna(False)

    report["rows_after"] = int(len(out))
    report["rows_removed"] = int(len(df) - len(out))
    report["missing_after"] = {c: int(out[c].isna().sum()) for c in numeric}
    report["imputation_performed"] = False
    report["note"] = "Faltantes financeiros permanecem como NaN; flags permitem tratá-los sem inventar valores."
    return out, report


def detect_outliers_iqr(df: pd.DataFrame, columns: list[str] | None = None) -> pd.DataFrame:
    """Marca outliers pelo IQR; não remove observações."""
    out = df.copy()
    columns = columns or [c for c in NUMERIC_CANDIDATES if c in out.columns]
    for col in columns:
        s = pd.to_numeric(out[col], errors="coerce")
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        if pd.isna(iqr) or iqr == 0:
            out[f"flag_outlier_{col}"] = False
            continue
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        out[f"flag_outlier_{col}"] = s.lt(low) | s.gt(high)
    return out


def run_lab02_quality(df: pd.DataFrame, output_dir: Path) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    before = audit_dataset(df)
    clean, treatment = clean_financial_dataset(df)
    clean = detect_outliers_iqr(clean)
    after = audit_dataset(clean)

    report = {"before": before, "treatment": treatment, "after": after}
    clean.to_csv(output_dir / "lab02_clean_financial_dataset.csv", index=False)
    pd.DataFrame(treatment["actions"]).to_csv(output_dir / "lab02_treatment_log.csv", index=False)
    (output_dir / "lab02_quality_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    return {"data": clean, "report": report}
