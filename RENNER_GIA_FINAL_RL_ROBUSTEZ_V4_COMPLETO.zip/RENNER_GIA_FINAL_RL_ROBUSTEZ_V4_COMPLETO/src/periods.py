import re
import pandas as pd


def normalize_label(value):
    if pd.isna(value):
        return None
    return re.sub(r'\s+', ' ', str(value).strip())


def parse_period(value):
    if pd.isna(value):
        return None
    s = normalize_label(value)
    if not s:
        return None
    # Common Renner labels: 1Q05, 1H05, 9M05, 12M05, 2024-03-31, etc.
    m = re.fullmatch(r'(\d+)(Q|H|M)(\d{2,4})', s.upper())
    if m:
        n, kind, year = int(m.group(1)), m.group(2), int(m.group(3))
        year += 2000 if year < 100 else 0
        if kind == 'Q' and n in (1, 2, 3, 4):
            return pd.Period(f'{year}Q{n}', freq='Q')
        if kind == 'H' and n in (1, 2):
            return pd.Period(f'{year}Q{1 if n == 1 else 4}', freq='Q')
        if kind == 'M' and n in (3, 6, 9, 12):
            return pd.Period(f'{year}Q{n // 3}', freq='Q')
    dt = pd.to_datetime(s, errors='coerce', dayfirst=False)
    if pd.notna(dt):
        return dt.to_period('Q')
    return None


def period_kind(label):
    if pd.isna(label):
        return None
    s = normalize_label(label).upper()
    if re.fullmatch(r'\dQ\d{2,4}', s): return 'quarter'
    if re.fullmatch(r'\dH\d{2,4}', s): return 'half_year_accumulated'
    if re.fullmatch(r'\dM\d{2,4}', s): return 'months_accumulated'
    if re.fullmatch(r'\d{4}', s): return 'annual'
    if 'LTM' in s: return 'ltm'
    if parse_period(s) is not None: return 'date'
    return None
