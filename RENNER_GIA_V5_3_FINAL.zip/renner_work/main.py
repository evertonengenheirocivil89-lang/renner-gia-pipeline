from pathlib import Path
import sys
import time
import logging
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from config import WORKBOOK, RAW, PROCESSED, FEATURES, OUTPUTS, SHEETS, TARGET_METRICS
from src.logging_setup import setup_logging
from src.config_loader import load_settings
from src.features.engineering import add_temporal_features
from src.models.validation import walk_forward_evaluate, regression_metrics, compare_revenue_forecasts
from src.etl.excel import ingest_workbook
from src.etl.financial import build_financial_panel
from src.etl.credit import build_credit_panel
from src.etl.esg import build_esg_dataset
from src.etl.data_marts import build_financial_mart
from src.ingestion.official_sources import source_register
from src.ingestion.ri_renner import build_ri_document_register, build_ri_manifest
from src.analysis.advanced_indicators import add_advanced_indicators
from src.analysis.trends import add_trend_features
from src.analysis.volatility import add_volatility
from src.risk.var import operating_shock_var
from src.risk.stress import stress_table
from src.models.forecast_advanced import arima_forecast
from src.gia.decision_engine import build_alerts
from src.esg.metrics import validate_esg_columns
from src.esg.climate_report import build_climate_risk_mart, build_emissions_mart, build_climate_targets_mart, build_climate_opportunity_mart
from src.gia.climate_engine import build_climate_alerts
from src.gia.report import build_report
from src.orchestration import PipelineRunner
from src.reinforcement.trainer import QConfig, search_configurations, train_q_learning
from src.reinforcement.evaluation import evaluate_policy
from src.reinforcement.policy_diagnostics import evaluate_baseline, evaluate_rl_with_diagnostics, compare_policy_to_baseline
from src.reinforcement.uncertainty import monte_carlo_policy, train_multi_seed, confidence_interval
from src.reinforcement.transition_model import fit_transition_model
from src.etl.data_engineering_lab import run_lab01_engineering
from src.etl.lab02_quality import run_lab02_quality

def _merge_roic(panel, frames):
    roic = frames.get("roic", pd.DataFrame()).copy()
    if roic.empty:
        return panel
    roic = roic[roic["metric"].astype(str).str.strip().str.casefold().isin({"% roic","roic"})].copy()
    if roic.empty:
        return panel
    roic["value"] = pd.to_numeric(roic["value"], errors="coerce")
    r = roic.groupby("period")["value"].last().rename("roic")
    # Workbook ROIC is already expressed as a ratio in the source; values > 1 are
    # converted only when clearly stored as percentage points.
    r = r.map(lambda x: x/100 if pd.notna(x) and x > 1 else x)
    return panel.join(r, how="left")

def _make_plots(panel, outdir):
    import matplotlib.pyplot as plt
    outdir.mkdir(parents=True, exist_ok=True)
    for col, title in [
        ("revenue","Receita operacional líquida"),
        ("net_income","Lucro líquido"),
        ("ebitda_margin","Margem EBITDA"),
        ("net_margin","Margem líquida"),
        ("roic","ROIC"),
    ]:
        if col not in panel.columns:
            continue
        fig, ax = plt.subplots(figsize=(10,5))
        ax.plot(panel.index, panel[col])
        ax.set_title(title)
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(outdir/f"{col}.png", dpi=160)
        plt.close(fig)

def run():
    logger = setup_logging(ROOT / "logs")
    settings = load_settings(ROOT / "config" / "settings.json")
    run_start = time.perf_counter()
    runner = PipelineRunner(logger, ROOT / "outputs" / "run_manifest.json")
    logger.info("Pipeline iniciado", extra={"stage":"pipeline"})
    for d in (PROCESSED, FEATURES, OUTPUTS, RAW/"RI", RAW/"CVM", RAW/"ESG"):
        Path(d).mkdir(parents=True, exist_ok=True)

    frames, audit = runner.run_stage(
        "ingestion",
        lambda: ingest_workbook(WORKBOOK, SHEETS),
        required=True,
    )
    logger.info(f"Ingestão concluída: {len(frames)} estruturas", extra={"stage":"ingestion"})

    financial = runner.run_stage(
        "financial_panel",
        lambda: build_financial_panel(frames, TARGET_METRICS),
        required=True,
    )
    if financial.empty:
        raise RuntimeError("Painel financeiro vazio após validação.")

    # Analytical layer uses standalone quarters from the validated financial ETL.
    panel = financial.copy().sort_index()
    panel = _merge_roic(panel, frames)
    panel["revenue_growth"] = panel["revenue"].pct_change(4, fill_method=None) if "revenue" in panel else np.nan

    panel = add_advanced_indicators(panel)
    # Indicadores financeiros adicionais: calculados apenas quando os componentes reais existem.
    financial_indicator_cols = [c for c in ["operating_margin","roe","capex_revenue","fcf_yield"] if c in panel.columns]
    metric_cols = [c for c in ["revenue","net_income","ebitda","net_margin","ebitda_margin","roic"] if c in panel.columns]
    panel = add_trend_features(panel, metric_cols)
    panel = add_volatility(panel, metric_cols)
    panel = add_temporal_features(panel)
    logger.info("Features temporais calculadas", extra={"stage":"features"})

    # Engenharia de Dados — Lab01 adaptado à Renner.
    # Esta etapa ocorre antes de ML/RL para que o pipeline use um dataset
    # analítico reproduzível, com profiling, features derivadas, rankings e gráficos.
    lab01 = runner.run_stage(
        "data_engineering_lab01",
        lambda: run_lab01_engineering(panel, PROCESSED / "lab01_engineering"),
        required=True,
    )
    logger.info(
        "Lab01 engenharia de dados: %s linhas, %s colunas",
        lab01["profile"]["shape_rows"],
        lab01["profile"]["shape_columns"],
        extra={"stage": "data_engineering"},
    )

    # O painel analítico validado pelo Lab01 passa a ser a base da camada
    # seguinte. O índice temporal é restaurado para manter compatibilidade
    # com os módulos existentes.
    engineered_panel = lab01["data"].copy().set_index("period")
    engineered_panel.index.name = "period"
    for col in engineered_panel.columns:
        if col != "period":
            engineered_panel[col] = pd.to_numeric(engineered_panel[col], errors="coerce")
    panel = panel.join(
        engineered_panel[[c for c in engineered_panel.columns if c not in panel.columns]],
        how="left",
    )

    # Lab02 — qualidade e tratamento. Faltantes financeiros não são imputados
    # automaticamente; o tratamento cria flags e um log auditável.
    lab02 = runner.run_stage(
        "data_engineering_lab02_quality",
        lambda: run_lab02_quality(panel, PROCESSED / "lab02_quality"),
        required=True,
    )
    logger.info(
        "Lab02 qualidade: %s -> %s linhas; imputação=%s",
        lab02["report"]["before"]["rows_before"],
        lab02["report"]["after"]["rows_before"],
        lab02["report"]["treatment"]["imputation_performed"],
        extra={"stage": "data_quality_lab02"},
    )

    # Flags de qualidade entram no painel, mas não substituem os valores originais.
    cleaned_panel = lab02["data"].copy()
    if "period" in cleaned_panel.columns:
        cleaned_panel = cleaned_panel.set_index("period")
    elif cleaned_panel.index.name == "period":
        cleaned_panel.index = pd.to_datetime(cleaned_panel.index, errors="coerce")
    else:
        raise KeyError("Painel Lab02 sem coluna ou índice 'period'.")
    quality_cols = [c for c in cleaned_panel.columns if c.startswith("flag_") or c in {"data_completeness_ratio", "financial_data_complete"}]
    if quality_cols:
        panel = panel.join(cleaned_panel[quality_cols], how="left", rsuffix="_lab02")

    credit = runner.run_stage(
        "credit_panel",
        lambda: build_credit_panel(frames),
        required=False,
        fallback=pd.DataFrame(),
    )
    if not credit.empty:
        credit.to_csv(PROCESSED/"credit_panel.csv", index=False)

    risk = runner.run_stage(
        "financial_risk",
        lambda: {
            "revenue_growth_var_95": operating_shock_var(panel["revenue_growth"], 0.95) if "revenue_growth" in panel else np.nan,
            "revenue_stress": stress_table(panel["revenue"], settings.get("risk", {}).get("stress_sigma", [0.5,1.0,1.5,2.0])) if "revenue" in panel else pd.DataFrame(),
        },
        required=False, fallback={}
    )
    if isinstance(risk, dict) and isinstance(risk.get("revenue_stress"), pd.DataFrame):
        risk["revenue_stress"].to_csv(PROCESSED/"revenue_stress.csv", index=False)
    alerts = runner.run_stage(
        "gia_alerts",
        lambda: build_alerts(panel, rules=settings.get("gia_rules")),
        required=False,
        fallback=pd.DataFrame(),
    )
    forecasts = runner.run_stage(
        "forecast",
        lambda: {c: arima_forecast(panel, c, periods=int(settings.get("forecast_periods",4)), min_points=int(settings.get("forecast_min_points",16))) for c in ["revenue","net_income"]},
        required=False,
        fallback={},
    )
    forecast_text = "\n".join(
        f"- {c}: {r['status']}; próximos valores={[float(x) for x in r['forecast'].round(2).values] if not r['forecast'].empty else 'N/D'}"
        for c,r in forecasts.items()
    )

    # Comparação temporal de modelos: baseline ingênuo, ARIMA e Ridge no mesmo
    # horizonte e sem vazamento de informação futura.
    forecast_comparison, forecast_metrics_df = runner.run_stage(
        "forecast_model_comparison",
        lambda: compare_revenue_forecasts(
            panel, target="revenue",
            min_train=int(settings.get("min_train_rows", 12)),
            ridge_alpha=float(settings.get("forecast_ridge_alpha", 1.0)),
        ),
        required=False, fallback=(pd.DataFrame(), pd.DataFrame()),
    )
    forecast_comparison.to_csv(PROCESSED/"forecast_model_predictions.csv", index=False)
    forecast_metrics_df.to_csv(PROCESSED/"forecast_model_metrics.csv", index=False)
    if not forecast_metrics_df.empty:
        forecast_text += "\n" + "\n".join(
            f"- comparação {r['model']}: MAE={r['mae']:.2f}; RMSE={r['rmse']:.2f}; sMAPE={r['smape']:.2f}%; Bias={r['bias']:.2f}; N={int(r['n'])}"
            for _, r in forecast_metrics_df.iterrows()
        )

    # Validação temporal: o modelo é avaliado apenas com informação disponível até cada ponto.
    wf_rows = []
    if "revenue" in panel.columns:
        def _run_validation():
            candidate = panel.reset_index().rename(columns={panel.index.name or "index":"period"})
            candidate["lag_revenue"] = candidate["revenue"].shift(1)
            candidate["lag_net_income"] = candidate["net_income"].shift(1) if "net_income" in candidate else np.nan
            from sklearn.linear_model import Ridge
            wf = walk_forward_evaluate(candidate, "revenue", ["lag_revenue"], lambda: Ridge(alpha=1.0), min_train=int(settings.get("min_train_rows",12)))
            metrics = regression_metrics(wf)
            pd.DataFrame([metrics]).to_csv(PROCESSED/"walk_forward_metrics.csv", index=False)
            return metrics

        metrics = runner.run_stage(
            "walk_forward_validation",
            _run_validation,
            required=False,
            fallback={"mae": np.nan, "rmse": np.nan, "n": 0},
        )
        logger.info(f"Walk-forward revenue: {metrics}", extra={"stage":"validation"})
    esg_sources = runner.run_stage(
        "esg_sources",
        lambda: build_esg_dataset(RAW/"ESG"),
        required=False,
        fallback=pd.DataFrame(),
    )
    # ESG climático estruturado a partir do relatório IFRS S1/S2 2025 fornecido.
    climate_risks = runner.run_stage("climate_risk_mart", build_climate_risk_mart, required=True)
    emissions = runner.run_stage("emissions_mart", build_emissions_mart, required=True)
    climate_targets = runner.run_stage("climate_targets_mart", build_climate_targets_mart, required=True)
    climate_opportunities = runner.run_stage("climate_opportunities_mart", build_climate_opportunity_mart, required=True)
    climate_alerts = runner.run_stage(
        "climate_alerts",
        lambda: build_climate_alerts(climate_risks),
        required=True,
    )
    esg_status = runner.run_stage(
        "esg_validation",
        lambda: validate_esg_columns(pd.DataFrame()),
        required=False,
        fallback=pd.DataFrame(),
    )
    esg_status.to_csv(PROCESSED/"esg_validation.csv", index=False)
    source_reg = runner.run_stage(
        "source_register",
        lambda: source_register(RAW),
        required=False,
        fallback=pd.DataFrame(),
    )
    # RI Renner passa a ser a fonte oficial de origem; o catálogo só registra
    # arquivos efetivamente disponíveis localmente e preserva o URL oficial.
    ri_catalog, ri_meta = runner.run_stage(
        "ri_manifest",
        lambda: build_ri_manifest(RAW, PROCESSED/'ri_manifest.csv'),
        required=False,
        fallback=(pd.DataFrame(), {"online_download_attempted": False}),
    )
    ri_docs = runner.run_stage(
        "ri_document_register",
        lambda: build_ri_document_register(RAW),
        required=False,
        fallback=pd.DataFrame(),
    )
    ri_docs.to_csv(PROCESSED/'ri_document_register.csv', index=False)

    # Aprendizagem por reforço: seleção de política somente no bloco de desenvolvimento.
    # O bloco final temporal permanece intocado até a avaliação.
    rl_results = pd.DataFrame()
    rl_policy = pd.DataFrame()
    rl_metrics = {}
    rl_baseline_metrics = {}
    rl_comparison = {}
    rl_diagnostics = pd.DataFrame()
    rl_seed_results = pd.DataFrame()
    rl_mc_results = pd.DataFrame()
    rl_uncertainty_metrics = {}
    if len(panel) >= 16:
        split = max(8, int(len(panel) * 0.80))
        split = min(split, len(panel) - 4)
        panel_dev = panel.iloc[:split].copy()
        panel_test = panel.iloc[split:].copy()
        # Modelo de transição: ajustado exclusivamente no desenvolvimento para evitar leakage.
        transition_model = runner.run_stage(
            "rl_transition_model",
            lambda: fit_transition_model(panel_dev),
            required=False, fallback=None,
        )
        # Busca econômica em três etapas, inspirada no laboratório: cada etapa
        # altera apenas uma dimensão e reutiliza configurações já treinadas.
        final_episodes = int(settings.get("rl", {}).get("final_episodes", settings.get("rl", {}).get("episodes", 80)))
        def _rl_search():
            nonlocal rl_results
            cache = {}
            search_episodes = int(settings.get("rl", {}).get("search_episodes", 30))
            alpha_grid = settings.get("rl", {}).get("alpha", [0.05, 0.10, 0.20])
            gamma_grid = settings.get("rl", {}).get("gamma", [0.80, 0.90, 0.98])
            epsilon_grid = settings.get("rl", {}).get("epsilon", [0.10, 0.20])
            def run(cfgs):
                ranked = search_configurations(panel_dev, cfgs, transition_model=transition_model)
                for r in ranked:
                    key = (r["config"].alpha, r["config"].gamma, r["config"].epsilon)
                    cache[key] = r
                return ranked[0]
            best1 = run([QConfig(alpha=a, gamma=0.90, epsilon=0.20, episodes=search_episodes, seed=42) for a in alpha_grid])
            best2 = run([QConfig(alpha=best1["config"].alpha, gamma=g, epsilon=0.20, episodes=search_episodes, seed=42) for g in gamma_grid])
            best3 = run([QConfig(alpha=best2["config"].alpha, gamma=best2["config"].gamma, epsilon=e, episodes=search_episodes, seed=42) for e in epsilon_grid])
            rows = list(cache.values())
            rl_results = pd.DataFrame([{
                "Etapas": "1-3", "alpha": r["config"].alpha, "gamma": r["config"].gamma,
                "epsilon": r["config"].epsilon, "episodes": r["config"].episodes,
                "mean_tail_reward": r["mean_tail_reward"],
                "std_tail_reward": r["std_tail_reward"], "states": r["states"]
            } for r in rows]).sort_values(["mean_tail_reward", "std_tail_reward"], ascending=[False, True])
            return best3
        rl_best = runner.run_stage("rl_hyperparameter_search", _rl_search, required=False, fallback=None)
        if rl_best is not None:
            # Retreino final somente no desenvolvimento, sem tocar no teste temporal.
            final_config = QConfig(alpha=rl_best["config"].alpha, gamma=rl_best["config"].gamma, epsilon=rl_best["config"].epsilon, episodes=final_episodes, seed=42)
            q_final, rl_history = runner.run_stage(
                "rl_final_training",
                lambda: train_q_learning(panel_dev, final_config, transition_model=transition_model),
                required=False, fallback=({}, pd.DataFrame()),
            )
            rl_policy, rl_metrics = runner.run_stage(
                "rl_temporal_holdout",
                lambda: evaluate_policy(panel_test, q_final, transition_model=transition_model),
                required=False, fallback=(pd.DataFrame(), {}),
            )
            rl_diagnostics, rl_diag_metrics = runner.run_stage(
                "rl_policy_diagnostics",
                lambda: evaluate_rl_with_diagnostics(panel_test, q_final, transition_model=transition_model),
                required=False, fallback=(pd.DataFrame(), {}),
            )
            rl_baseline, rl_baseline_metrics = runner.run_stage(
                "rl_baseline",
                lambda: evaluate_baseline(panel_test, transition_model=transition_model, action=0),
                required=False, fallback=(pd.DataFrame(), {}),
            )
            rl_comparison = compare_policy_to_baseline(rl_diagnostics, rl_baseline)
            rl_metrics.update({f"policy_{k}": v for k, v in rl_diag_metrics.items() if k not in rl_metrics})
            rl_policy = rl_diagnostics
            # Estabilidade: mesma configuração treinada com sementes distintas.
            rl_seed_config = QConfig(alpha=final_config.alpha, gamma=final_config.gamma, epsilon=final_config.epsilon, episodes=final_config.episodes, seed=42)
            rl_seed_results, rl_seed_models = runner.run_stage(
                "rl_multi_seed",
                lambda: train_multi_seed(
                    panel_dev, rl_seed_config, transition_model=None, seeds=tuple(settings.get("rl", {}).get("seeds", [11, 22, 33]))
                ),
                required=False, fallback=(pd.DataFrame(), []),
            )
            if isinstance(rl_seed_results, pd.DataFrame) and not rl_seed_results.empty:
                rl_seed_results["evaluation_mode"] = "training_stability_on_observed_transitions"
            seed_ci_low, seed_ci_high = confidence_interval(rl_seed_results["mean_tail_reward"], confidence=0.95)
            # Monte Carlo: propaga a incerteza residual da transição sobre a política final.
            rl_mc_results, rl_uncertainty_metrics = runner.run_stage(
                "rl_monte_carlo",
                lambda: monte_carlo_policy(
                    panel_test, q_final, transition_model=transition_model, n_simulations=int(settings.get("risk", {}).get("monte_carlo_simulations", 250)), seed=2026
                ),
                required=False, fallback=(pd.DataFrame(), {}),
            )
            rl_uncertainty_metrics.update({
                "seed_mean_tail_reward": float(rl_seed_results["mean_tail_reward"].mean()),
                "seed_std_tail_reward": float(rl_seed_results["mean_tail_reward"].std(ddof=1)) if len(rl_seed_results) > 1 else 0.0,
                "seed_ci95_low": seed_ci_low,
                "seed_ci95_high": seed_ci_high,
                "n_training_seeds": int(len(rl_seed_results)),
            })
            rl_metrics.update({f"uncertainty_{k}": v for k, v in rl_uncertainty_metrics.items()})
            rl_baseline.to_csv(PROCESSED/"rl_baseline_test.csv", index=False)
            pd.DataFrame([rl_baseline_metrics]).to_csv(PROCESSED/"rl_baseline_metrics.csv", index=False)
            pd.DataFrame([rl_comparison]).to_csv(PROCESSED/"rl_policy_vs_baseline.csv", index=False)
            rl_diagnostics.to_csv(PROCESSED/"rl_policy_diagnostics.csv", index=False)
            rl_results.to_csv(PROCESSED/"rl_hyperparameter_search.csv", index=False)
            rl_history.to_csv(PROCESSED/"rl_training_history.csv", index=False)
            rl_policy.to_csv(PROCESSED/"rl_policy_test.csv", index=False)
            pd.DataFrame([rl_metrics]).to_csv(PROCESSED/"rl_test_metrics.csv", index=False)
            rl_seed_results.to_csv(PROCESSED/"rl_seed_stability.csv", index=False)
            rl_mc_results.to_csv(PROCESSED/"rl_monte_carlo.csv", index=False)
            pd.DataFrame([rl_uncertainty_metrics]).to_csv(PROCESSED/"rl_uncertainty_metrics.csv", index=False)
            logger.info(f"RL temporal holdout: {rl_metrics}", extra={"stage":"reinforcement"})

    panel.to_csv(FEATURES/"advanced_financial_features.csv")
    alerts.to_csv(PROCESSED/"gia_alerts.csv", index=False)
    climate_risks.to_csv(PROCESSED/"climate_risk_mart.csv", index=False)
    emissions.to_csv(PROCESSED/"emissions_mart.csv", index=False)
    climate_targets.to_csv(PROCESSED/"climate_targets_mart.csv", index=False)
    climate_opportunities.to_csv(PROCESSED/"climate_opportunities_mart.csv", index=False)
    climate_alerts.to_csv(PROCESSED/"climate_alerts.csv", index=False)
    source_reg.to_csv(PROCESSED/"source_register.csv", index=False)
    _make_plots(panel, OUTPUTS/"plots")

    report = runner.run_stage(
        "report",
        lambda: build_report(panel, alerts, forecast_text, esg_status, OUTPUTS/"Relatorio_Executivo_Renner_GIA_FINAL.md", climate_risks, emissions, climate_targets, climate_opportunities, rl_metrics, rl_results, rl_baseline_metrics, rl_comparison),
        required=True,
    )

    with pd.ExcelWriter(OUTPUTS/"renner_gia_FINAL_analysis.xlsx", engine="openpyxl") as writer:
        audit.to_excel(writer, sheet_name="audit", index=False)
        panel.reset_index().to_excel(writer, sheet_name="advanced_features", index=False)
        lab01["data"].to_excel(writer, sheet_name="lab01_dataset", index=False)
        pd.DataFrame([lab01["profile"]]).to_excel(writer, sheet_name="lab01_profile", index=False)
        lab02["data"].to_excel(writer, sheet_name="lab02_quality_data", index=False)
        pd.DataFrame([lab02["report"]["before"], lab02["report"]["after"]], index=["before", "after"]).to_excel(writer, sheet_name="lab02_quality_profile")
        pd.DataFrame(lab02["report"]["treatment"]["actions"]).to_excel(writer, sheet_name="lab02_treatment_log", index=False)
        for name, table in lab01["rankings"].items():
            sheet = ("lab01_" + name)[:31]
            table.to_excel(writer, sheet_name=sheet, index=False)
        alerts.to_excel(writer, sheet_name="gia_alerts", index=False)
        if not rl_results.empty:
            rl_results.to_excel(writer, sheet_name="rl_hyperparams", index=False)
        if not rl_policy.empty:
            rl_policy.to_excel(writer, sheet_name="rl_policy_test", index=False)
        if rl_metrics:
            pd.DataFrame([rl_metrics]).to_excel(writer, sheet_name="rl_test_metrics", index=False)
        if rl_baseline_metrics:
            pd.DataFrame([rl_baseline_metrics]).to_excel(writer, sheet_name="rl_baseline_metrics", index=False)
        if rl_comparison:
            pd.DataFrame([rl_comparison]).to_excel(writer, sheet_name="rl_policy_vs_base", index=False)
        if not rl_diagnostics.empty:
            rl_diagnostics.to_excel(writer, sheet_name="rl_diagnostics", index=False)
        if not rl_seed_results.empty:
            rl_seed_results.to_excel(writer, sheet_name="rl_seed_stability", index=False)
        if not rl_mc_results.empty:
            rl_mc_results.to_excel(writer, sheet_name="rl_monte_carlo", index=False)
        if rl_uncertainty_metrics:
            pd.DataFrame([rl_uncertainty_metrics]).to_excel(writer, sheet_name="rl_uncertainty", index=False)
        forecast_comparison.to_excel(writer, sheet_name="forecast_predictions", index=False)
        forecast_metrics_df.to_excel(writer, sheet_name="forecast_metrics", index=False)
        esg_status.to_excel(writer, sheet_name="esg_validation", index=False)
        ri_docs.to_excel(writer, sheet_name="ri_documents", index=False)
        climate_risks.to_excel(writer, sheet_name="climate_risks", index=False)
        emissions.to_excel(writer, sheet_name="emissions", index=False)
        climate_targets.to_excel(writer, sheet_name="climate_targets", index=False)
        climate_opportunities.to_excel(writer, sheet_name="climate_opportunities", index=False)
        climate_alerts.to_excel(writer, sheet_name="climate_alerts", index=False)

    elapsed = time.perf_counter() - run_start
    runner.finalize("SUCCESS")
    logger.info(f"Pipeline concluído em {elapsed:.2f}s", extra={"stage":"pipeline"})
    return report

if __name__ == "__main__":
    print(run())
