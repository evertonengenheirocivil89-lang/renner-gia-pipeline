# Renner GIA v4 — Relatório de Qualidade Inicial

**Abas:** 19

**Células ND identificadas:** 766

**Duplicidades exatas por linha:** 227


## Inventário

| sheet                        |   rows |   columns |   nonempty_rows |   ND_cells |   duplicate_rows_exact |
|:-----------------------------|-------:|----------:|----------------:|-----------:|-----------------------:|
| Home                         |     39 |        26 |               0 |          0 |                     38 |
| Balance Sheet                |     74 |        92 |              60 |          0 |                     13 |
| Income Statement             |     63 |       153 |              47 |        291 |                     15 |
| Cash Flow                    |     51 |        34 |              42 |          0 |                      8 |
| Accounts Receivables         |     58 |       148 |              30 |          0 |                     27 |
| Estimated Credit Losses IFRS |     89 |       146 |              78 |          0 |                     14 |
| NPL Formation                |     16 |        25 |               9 |          0 |                      6 |
| Financial Services           |     37 |       127 |              26 |        128 |                     10 |
| EBITDA                       |     58 |       153 |              25 |          0 |                     32 |
| EBITDA Ex-IFRS 16            |     24 |        20 |              18 |          0 |                      5 |
| Operating Data               |     77 |       155 |              61 |        347 |                     15 |
| B&M Units                    |    827 |        15 |             819 |          0 |                      7 |
| TD                           |     17 |         7 |              15 |          0 |                      1 |
| ROIC                         |     32 |        11 |              22 |          0 |                      9 |
| CAPEX                        |     15 |       153 |               8 |          0 |                      6 |
| Dividends and IOC            |    115 |        12 |             110 |          0 |                      4 |
| Receivables BACEN            |     71 |        82 |              57 |          0 |                     17 |
| UF                           |     30 |         5 |              30 |          0 |                      0 |
| Quarters                     |     13 |         3 |              13 |          0 |                      0 |

## Cabeçalhos detectados

| sheet                        |   detected_header_row |   score |   period_labels |
|:-----------------------------|----------------------:|--------:|----------------:|
| Home                         |                     1 |       0 |               0 |
| Balance Sheet                |                     6 |      88 |               0 |
| Income Statement             |                     6 |     536 |             128 |
| Cash Flow                    |                     6 |     114 |              27 |
| Accounts Receivables         |                     6 |      33 |               2 |
| Estimated Credit Losses IFRS |                     6 |      33 |               2 |
| NPL Formation                |                     6 |      24 |               0 |
| Financial Services           |                     6 |     439 |             105 |
| EBITDA                       |                     6 |     536 |             128 |
| EBITDA Ex-IFRS 16            |                     6 |      64 |              15 |
| Operating Data               |                     6 |     536 |             128 |
| B&M Units                    |                     6 |      14 |               0 |
| TD                           |                     6 |       7 |               0 |
| ROIC                         |                     6 |      10 |               0 |
| CAPEX                        |                     6 |     536 |             128 |
| Dividends and IOC            |                     7 |       7 |               0 |
| Receivables BACEN            |                     6 |      79 |               0 |
| UF                           |                     1 |       5 |               0 |
| Quarters                     |                     1 |       2 |               0 |

## Regras

- `ND` permanece ausente; não vira zero.

- Nenhuma interpolação nesta etapa.

- Nenhum scaler estatístico nesta etapa.

- A normalização estrutural ocorre antes das features.

- `StandardScaler`/`MinMaxScaler` será ajustado somente no treino.
