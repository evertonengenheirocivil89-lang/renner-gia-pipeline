from pathlib import Path
import pandas as pd

RI_DIRS = ('RI', 'CVM', 'ESG')


def inventory_public_sources(raw_dir):
    rows = []
    raw = Path(raw_dir)
    for folder in RI_DIRS:
        d = raw / folder
        for p in sorted(d.glob('*')):
            if p.is_file() and not p.name.startswith('.'):
                rows.append({'source': folder, 'file': p.name, 'path': str(p), 'extension': p.suffix.lower()})
    return pd.DataFrame(rows)
