import numpy as np
import pandas as pd

from src.reinforcement.uncertainty import confidence_interval, monte_carlo_policy
from src.reinforcement.trainer import QConfig, train_q_learning
from src.reinforcement.transition_model import fit_transition_model


def _panel(n=20):
    idx = pd.date_range("2022-03-31", periods=n, freq="QE")
    x = np.linspace(0.01, 0.04, n)
    return pd.DataFrame({
        "revenue_growth": x, "net_margin": 0.08 + x, "ebitda_margin": 0.15 + x,
        "roic": 0.12 + x, "cash_revenue": 0.10 + x, "npl_ratio": 0.04 - x/2,
        "inventory_growth": x, "receivables_growth": x/2,
        "revenue_volatility_4q": 0.02 + x/5, "net_income_volatility_4q": 0.03 + x/5,
        "climate_risk_score": 0.10 + x/10,
    }, index=idx)


def test_confidence_interval_singleton():
    assert confidence_interval([2.0]) == (2.0, 2.0)


def test_monte_carlo_reproducible_and_nonempty():
    panel = _panel()
    tm = fit_transition_model(panel.iloc[:15])
    q, _ = train_q_learning(panel.iloc[:15], QConfig(episodes=8, seed=7), transition_model=tm)
    a, sa = monte_carlo_policy(panel.iloc[15:], q, tm, n_simulations=12, seed=99)
    b, sb = monte_carlo_policy(panel.iloc[15:], q, tm, n_simulations=12, seed=99)
    assert len(a) == 12
    assert a.equals(b)
    assert sa["mc_n_simulations"] == 12
    assert np.isfinite(sa["mc_total_reward_mean"])
