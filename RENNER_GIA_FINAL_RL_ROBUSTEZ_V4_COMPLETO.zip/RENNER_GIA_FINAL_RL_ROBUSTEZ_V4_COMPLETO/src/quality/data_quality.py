from pathlib import Path
from openpyxl import load_workbook
import pandas as pd

def profile_workbook(path: str | Path) -> pd.DataFrame:
    wb = load_workbook(path, read_only=True, data_only=True)
    rows = []
    for ws in wb.worksheets:
        nonempty = nd = dup = 0
        seen = set()
        for row in ws.iter_rows(values_only=True):
            vals = tuple(row)
            if any(v is not None for v in vals):
                nonempty += 1
            if any(str(v).strip().upper() == "ND" for v in vals if v is not None):
                nd += sum(str(v).strip().upper() == "ND" for v in vals if v is not None)
            if vals in seen: dup += 1
            else: seen.add(vals)
        rows.append({"sheet":ws.title,"rows":ws.max_row,"columns":ws.max_column,
                     "nonempty_rows":nonempty,"ND_cells":nd,"duplicate_rows_exact":dup})
    return pd.DataFrame(rows)
