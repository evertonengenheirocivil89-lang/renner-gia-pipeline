from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

STATE_COLS = [
    "revenue_growth", "net_margin", "ebitda_margin", "roic",
    "cash_revenue", "npl_ratio", "inventory_growth", "receivables_growth",
    "revenue_volatility_4q", "net_income_volatility_4q", "climate_risk_score",
]

@dataclass
class TransitionModel:
    models: dict
    residual_std: dict
    feature_cols: list
    feature_map: dict | None = None

    def predict_next(self, row: pd.Series) -> pd.Series:
        out = {}
        for c, model in self.models.items():
            cols = (self.feature_map or {}).get(c, self.feature_cols)
            x = pd.DataFrame([{f: pd.to_numeric(row.get(f, np.nan), errors="coerce") for f in cols}])
            out[c] = float(model.predict(x)[0])
        return pd.Series(out)


def _make_model(alpha: float) -> Pipeline:
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("ridge", Ridge(alpha=alpha)),
    ])


def _oos_residual_std(X: pd.DataFrame, y: pd.Series, alpha: float, min_train: int = 12) -> float:
    """Estima sigma usando previsões one-step-ahead dentro do desenvolvimento.

    Evita usar resíduo in-sample para calibrar a incerteza Monte Carlo.
    """
    preds, actual = [], []
    for end in range(min_train, len(y)):
        X_train = X.iloc[:end]
        y_train = y.iloc[:end]
        if y_train.notna().sum() < min_train:
            continue
        model = _make_model(alpha)
        model.fit(X_train, y_train)
        x_next = X.iloc[[end]]
        if pd.isna(y.iloc[end]):
            continue
        preds.append(float(model.predict(x_next)[0]))
        actual.append(float(y.iloc[end]))
    if len(actual) >= 3:
        return float(np.std(np.asarray(actual) - np.asarray(preds), ddof=1))
    return 0.0


def fit_transition_model(panel: pd.DataFrame, alpha: float = 1.0) -> TransitionModel:
    """Aprende t -> t+1 somente no bloco fornecido.

    A previsão final usa todo o bloco de desenvolvimento, enquanto a sigma de
    incerteza usa resíduos one-step-ahead, reduzindo otimismo da incerteza.
    """
    df = panel.sort_index().copy()
    available = [c for c in STATE_COLS if c in df.columns]
    if len(available) < 5:
        raise ValueError("Poucas variáveis disponíveis para o modelo de transição.")
    X_all = df[available].apply(pd.to_numeric, errors="coerce").iloc[:-1]
    Y = df[available].apply(pd.to_numeric, errors="coerce").shift(-1).iloc[:-1]
    models, residual_std = {}, {}
    feature_map = {}
    for target in available:
        valid = Y[target].notna()
        usable_features = [c for c in available if X_all.loc[valid, c].notna().sum() >= 2]
        if target not in Y.columns:
            continue
        X = X_all[usable_features]
        if valid.sum() < max(12, len(available) + 3):
            continue
        model = _make_model(alpha)
        model.fit(X.loc[valid], Y.loc[valid, target])
        sigma = _oos_residual_std(X.loc[valid].reset_index(drop=True), Y.loc[valid, target].reset_index(drop=True), alpha)
        if sigma <= 0:
            pred = model.predict(X.loc[valid])
            sigma = float(np.std(Y.loc[valid, target].to_numpy() - pred, ddof=1)) if valid.sum() > 1 else 0.0
        residual_std[target] = sigma
        models[target] = model
        feature_map[target] = usable_features
    if not models:
        raise ValueError("Não foi possível ajustar nenhum componente da transição.")
    # Mantém a união das features utilizáveis; predict_next filtra por modelo.
    return TransitionModel(models=models, residual_std=residual_std, feature_cols=available, feature_map=feature_map)
