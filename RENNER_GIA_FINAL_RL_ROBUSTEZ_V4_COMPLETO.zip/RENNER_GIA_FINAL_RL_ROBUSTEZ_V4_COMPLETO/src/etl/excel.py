from pathlib import Path
import pandas as pd
from src.periods import normalize_label, parse_period, period_kind


def detect_header(path, sheet, max_rows=12, xls=None):
    preview = (xls.parse(sheet, header=None, nrows=max_rows) if xls is not None else pd.read_excel(path, sheet_name=sheet, header=None, nrows=max_rows))
    scores = []
    for i, row in preview.iterrows():
        vals = [normalize_label(x) for x in row.tolist()]
        score = sum(x is not None for x in vals)
        score += 2 * sum(bool(x and (parse_period(x) is not None or period_kind(x) is not None)) for x in vals)
        scores.append(score)
    return int(max(range(len(scores)), key=lambda i: scores[i]))


def read_sheet(path, sheet, xls=None):
    header = detect_header(path, sheet, xls=xls)
    df = xls.parse(sheet, header=header) if xls is not None else pd.read_excel(path, sheet_name=sheet, header=header)
    df.columns = [normalize_label(c) or f'col_{i}' for i, c in enumerate(df.columns)]
    return df, header


def to_long(df, source_sheet):
    # Prefer a metric/name column; otherwise use the first textual column.
    metric_col = next((c for c in df.columns if c.lower() in {'metric', 'item', 'description', 'indicator'}), None)
    if metric_col is None:
        candidates = [c for c in df.columns if df[c].dtype == 'object']
        metric_col = candidates[0] if candidates else df.columns[0]
    rows = []
    for _, r in df.iterrows():
        metric = normalize_label(r.get(metric_col))
        if not metric or metric.lower() in {'nan', 'none'}:
            continue
        for col, value in r.items():
            if col == metric_col:
                continue
            p = parse_period(col)
            if p is None:
                continue
            numeric = pd.to_numeric(value, errors='coerce')
            rows.append({'source_sheet': source_sheet, 'metric': metric,
                         'period_label': str(col), 'period': p.start_time,
                         'value': numeric})
    return pd.DataFrame(rows)


def ingest_workbook(path, sheet_map):
    frames, audit = {}, []
    xls = pd.ExcelFile(path)
    available = set(xls.sheet_names)
    for key, sheet in sheet_map.items():
        if sheet not in available:
            audit.append({'sheet': sheet, 'status': 'missing'})
            continue
        df, header = read_sheet(path, sheet, xls=xls)
        long_df = to_long(df, sheet)
        frames[key] = long_df
        audit.append({'sheet': sheet, 'status': 'ok', 'header_row': header,
                      'rows_raw': len(df), 'rows_long': len(long_df)})
    return frames, pd.DataFrame(audit)
