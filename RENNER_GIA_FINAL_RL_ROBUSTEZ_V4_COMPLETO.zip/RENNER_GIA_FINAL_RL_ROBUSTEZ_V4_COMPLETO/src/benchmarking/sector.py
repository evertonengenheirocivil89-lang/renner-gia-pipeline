import pandas as pd

def build_sector_benchmark(company_rows):
    # company_rows: list of dicts sourced from verified company disclosures.
    return pd.DataFrame(company_rows)
