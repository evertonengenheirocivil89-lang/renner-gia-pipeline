import numpy as np
import pandas as pd


def build_health_components(features):
    x = pd.DataFrame(index=features.index)
    if 'revenue_growth_yoy' in features: x['growth'] = features['revenue_growth_yoy']
    if 'net_margin' in features: x['profitability'] = features['net_margin']
    if 'equity_to_assets' in features: x['capitalization'] = features['equity_to_assets']
    if 'cash_to_revenue' in features: x['liquidity_proxy'] = features['cash_to_revenue']
    return x
