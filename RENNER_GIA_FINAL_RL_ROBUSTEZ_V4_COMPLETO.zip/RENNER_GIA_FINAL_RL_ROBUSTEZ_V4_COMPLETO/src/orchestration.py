from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Callable, Optional
import json
import logging
import traceback


@dataclass
class StageResult:
    name: str
    status: str
    elapsed_seconds: float
    error: Optional[str] = None
    traceback: Optional[str] = None

    def to_dict(self):
        return asdict(self)


class PipelineRunner:
    """Orquestrador resiliente: cada etapa é isolada e auditável."""

    def __init__(self, logger: logging.Logger, manifest_path: Path):
        self.logger = logger
        self.manifest_path = Path(manifest_path)
        self.results: list[StageResult] = []

    def run_stage(
        self,
        name: str,
        func: Callable[[], Any],
        *,
        required: bool = True,
        fallback: Any = None,
    ) -> Any:
        start = perf_counter()
        self.logger.info("Etapa iniciada", extra={"stage": name})

        try:
            result = func()
            elapsed = perf_counter() - start
            self.results.append(
                StageResult(name, "SUCCESS", elapsed)
            )
            self.logger.info(
                "Etapa concluída",
                extra={"stage": name, "elapsed_seconds": round(elapsed, 4)},
            )
            return result

        except Exception as exc:
            elapsed = perf_counter() - start
            tb = traceback.format_exc()
            status = "FAILED" if required else "FAILED_WITH_FALLBACK"
            self.results.append(
                StageResult(
                    name,
                    status,
                    elapsed,
                    error=str(exc),
                    traceback=tb,
                )
            )
            self.logger.exception(
                "Falha na etapa",
                extra={"stage": name, "elapsed_seconds": round(elapsed, 4)},
            )

            if required:
                raise

            self.logger.warning(
                "Aplicando fallback da etapa",
                extra={"stage": name},
            )
            return fallback

    def finalize(self, status: str = "SUCCESS"):
        payload = {
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "pipeline_status": status,
            "stages": [r.to_dict() for r in self.results],
            "summary": {
                "total": len(self.results),
                "success": sum(r.status == "SUCCESS" for r in self.results),
                "failed": sum(r.status == "FAILED" for r in self.results),
                "fallback": sum(r.status == "FAILED_WITH_FALLBACK" for r in self.results),
            },
        }
        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)
        self.manifest_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        self.logger.info(
            "Manifesto de execução salvo",
            extra={"stage": "orchestration"},
        )
        return payload
