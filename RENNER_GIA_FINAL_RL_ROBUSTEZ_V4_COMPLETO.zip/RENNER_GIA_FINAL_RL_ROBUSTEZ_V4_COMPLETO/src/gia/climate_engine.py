import pandas as pd

def build_climate_alerts(risks: pd.DataFrame) -> pd.DataFrame:
    if risks is None or risks.empty:
        return pd.DataFrame(columns=["risk_id","risk","alert","basis"])
    rows=[]
    for _, r in risks.iterrows():
        impact=r.get("financial_impact_2025_result_m")
        future=r.get("future_cf_high_m")
        if pd.notna(impact) and impact < 0:
            alert="IMPACTO FINANCEIRO OBSERVADO"
            basis=f"resultado operacional 2025: R$ {abs(float(impact)):.1f} mi"
        elif pd.notna(future):
            alert="RISCO FINANCEIRO PROJETADO"
            basis=f"limite superior do fluxo de caixa em 10 anos: R$ {float(future):.1f} mi"
        else:
            alert="MONITORAMENTO QUALITATIVO"
            basis=str(r.get("status_2025","N/D"))
        rows.append({"risk_id":r["risk_id"],"risk":r["risk"],"alert":alert,"basis":basis})
    return pd.DataFrame(rows)
