import numpy as np
import pandas as pd

DEFAULT_RULES = {
    "revenue_growth": {"warning": 0.00, "critical": -0.05, "direction":"higher_better"},
    "net_margin": {"warning": 0.07, "critical": 0.05, "direction":"higher_better"},
    "roic": {"warning": 0.12, "critical": 0.10, "direction":"higher_better"},
    "npl_ratio": {"warning": 0.06, "critical": 0.08, "direction":"lower_better"},
}

def status_for(value, rule):
    if pd.isna(value):
        return "N/D"
    if rule["direction"] == "higher_better":
        if value >= rule["warning"]: return "CONTROLE"
        if value >= rule["critical"]: return "ATENÇÃO"
        return "INVESTIGAÇÃO"
    if value <= rule["warning"]: return "CONTROLE"
    if value <= rule["critical"]: return "ATENÇÃO"
    return "INVESTIGAÇÃO"

def build_alerts(df, rules=None):
    rules = rules or DEFAULT_RULES
    rows = []
    if df.empty:
        return pd.DataFrame(columns=["period","indicator","value","status","parameter"])
    for _, r in df.sort_index().iterrows():
        for name, rule in rules.items():
            if name in df.columns:
                rows.append({
                    "period": r.name,
                    "indicator": name,
                    "value": r[name],
                    "status": status_for(r[name], rule),
                    "parameter": f'{rule["warning"]} / {rule["critical"]}'
                })
    return pd.DataFrame(rows)

def latest_diagnosis(df):
    if df.empty:
        return pd.DataFrame()
    r = df.sort_index().iloc[-1]
    rows = []
    for c in ["revenue_growth","net_margin","roic","npl_ratio"]:
        if c not in df.columns: continue
        v = r[c]
        if pd.isna(v): continue
        rows.append({
            "indicator": c,
            "current_value": float(v),
            "trend_4q": float(df[c].tail(4).mean()) if df[c].notna().any() else np.nan,
        })
    return pd.DataFrame(rows)
