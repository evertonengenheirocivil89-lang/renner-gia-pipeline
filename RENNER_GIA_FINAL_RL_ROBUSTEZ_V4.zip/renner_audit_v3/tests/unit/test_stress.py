import numpy as np
import pandas as pd

from src.reinforcement.stress import run_adverse_stress
from src.reinforcement.trainer import QConfig, train_q_learning
from src.reinforcement.transition_model import fit_transition_model


def _panel(n=24):
    idx = pd.date_range("2021-03-31", periods=n, freq="QE")
    x = np.linspace(0.01, 0.05, n)
    return pd.DataFrame({
        "revenue_growth": x, "net_margin": 0.08 + x, "ebitda_margin": .15+x,
        "roic": .12+x, "cash_revenue": .10+x, "npl_ratio": .04-x/2,
        "inventory_growth": x, "receivables_growth": x/2,
        "revenue_volatility_4q": .02+x/5, "net_income_volatility_4q": .03+x/5,
        "climate_risk_score": .10+x/10,
    }, index=idx)


def test_adverse_stress_reproducible_and_nonempty():
    panel = _panel()
    tm = fit_transition_model(panel.iloc[:18])
    q, _ = train_q_learning(panel.iloc[:18], QConfig(episodes=8, seed=7), transition_model=tm)
    a, sa = run_adverse_stress(panel.iloc[18:], q, tm, n_simulations=8, seed=123, shock_sigma=1.0)
    b, sb = run_adverse_stress(panel.iloc[18:], q, tm, n_simulations=8, seed=123, shock_sigma=1.0)
    assert a.equals(b)
    assert sa["stress_n_simulations"] == 8
    assert np.isfinite(sa["stress_total_reward_p05"])
