import pandas as pd

ESG_INDICATORS = {
    "ambiental": ["energy_consumption","water_consumption","ghg_emissions","waste_recycling","sustainable_suppliers"],
    "social": ["employees","female_leadership","turnover","training_hours","accidents","diversity"],
    "governance": ["independent_board","audit_committee","compliance_cases","data_privacy_incidents"],
}

def validate_esg_columns(df):
    available, missing = [], []
    for cols in ESG_INDICATORS.values():
        for c in cols:
            (available if c in df.columns else missing).append(c)
    return pd.DataFrame([{
        "available_count": len(available),
        "missing_count": len(missing),
        "coverage": len(available)/(len(available)+len(missing)) if available or missing else 0,
        "available": ", ".join(available),
        "missing": ", ".join(missing),
    }])
