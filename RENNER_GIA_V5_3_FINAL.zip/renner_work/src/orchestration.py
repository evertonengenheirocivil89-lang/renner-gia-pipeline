from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Callable, Optional
import json, logging, traceback

@dataclass
class StageResult:
    name: str; status: str; elapsed_seconds: float
    rows_input: Optional[int]=None; rows_output: Optional[int]=None
    error: Optional[str]=None; traceback: Optional[str]=None
    def to_dict(self): return asdict(self)

class PipelineRunner:
    def __init__(self, logger: logging.Logger, manifest_path: Path):
        self.logger=logger; self.manifest_path=Path(manifest_path); self.results=[]
    @staticmethod
    def _rows(obj):
        try: return int(len(obj)) if obj is not None else None
        except Exception: return None
    def run_stage(self,name,func,*,required=True,fallback=None):
        start=perf_counter(); self.logger.info("Etapa iniciada",extra={"stage":name,"status":"STARTED"})
        try:
            result=func(); elapsed=perf_counter()-start; rows=self._rows(result)
            self.results.append(StageResult(name,"SUCCESS",elapsed,None,rows))
            self.logger.info("Etapa concluída",extra={"stage":name,"elapsed_seconds":round(elapsed,4),"rows_output":rows,"status":"SUCCESS"})
            return result
        except Exception as exc:
            elapsed=perf_counter()-start; tb=traceback.format_exc(); status="FAILED" if required else "FAILED_WITH_FALLBACK"
            self.results.append(StageResult(name,status,elapsed,error=str(exc),traceback=tb))
            self.logger.exception("Falha na etapa",extra={"stage":name,"elapsed_seconds":round(elapsed,4),"status":status})
            if required: raise
            self.logger.warning("Aplicando fallback da etapa",extra={"stage":name,"status":"FALLBACK"}); return fallback
    def finalize(self,status="SUCCESS"):
        payload={"generated_at_utc":datetime.now(timezone.utc).isoformat(),"run_id":getattr(self.logger,"run_id",None),"pipeline_status":status,"stages":[r.to_dict() for r in self.results],"summary":{"total":len(self.results),"success":sum(r.status=="SUCCESS" for r in self.results),"failed":sum(r.status=="FAILED" for r in self.results),"fallback":sum(r.status=="FAILED_WITH_FALLBACK" for r in self.results)}}
        self.manifest_path.parent.mkdir(parents=True,exist_ok=True); self.manifest_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
        self.logger.info("Manifesto de execução salvo",extra={"stage":"orchestration","status":status}); return payload
