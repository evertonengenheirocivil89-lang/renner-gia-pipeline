"""Avaliação de incerteza para o ambiente RL da Renner.

As simulações são model-based: a incerteza vem dos resíduos do modelo de
transição ajustado no bloco de desenvolvimento. Não há criação de ações
históricas nem inferência causal.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .environment import ACTIONS, ACTION_EFFECTS, build_state, policy_guard, reward_from_transition, apply_action_scenario
from .trainer import greedy_policy, train_q_learning, QConfig


def _stochastic_next(current: pd.Series, transition_model, action: int, rng: np.random.Generator) -> pd.Series:
    pred = transition_model.predict_next(current)
    nxt = current.copy()
    for col, value in pred.items():
        sigma = float(transition_model.residual_std.get(col, 0.0))
        draw = rng.normal(0.0, sigma) if np.isfinite(sigma) and sigma > 0 else 0.0
        if np.isfinite(value):
            nxt[col] = float(value) + float(draw)
    return apply_action_scenario(nxt, current, transition_model, action)


def simulate_policy_once(panel: pd.DataFrame, q, transition_model, seed: int,
                         start: int = 0, end: int | None = None, prediction_cache=None) -> dict:
    rng = np.random.default_rng(seed)
    end = len(panel) - 1 if end is None else min(end, len(panel) - 1)
    i = int(start)
    total = 0.0
    cumulative_cost = 0.0
    rewards = []
    actions = []
    while i < end:
        current = panel.iloc[i]
        state = build_state(current)
        raw_action = greedy_policy(q, state, current)
        action = policy_guard(raw_action, current)
        pred = prediction_cache.get(i) if prediction_cache is not None else None
        if pred is not None:
            # Reutiliza a previsão determinística; apenas o residual é reamostrado.
            nxt = current.copy()
            for col, value in pred.items():
                sigma = float(transition_model.residual_std.get(col, 0.0))
                draw = rng.normal(0.0, sigma) if np.isfinite(sigma) and sigma > 0 else 0.0
                if np.isfinite(value):
                    nxt[col] = float(value) + float(draw)
            nxt = apply_action_scenario(nxt, current, transition_model, action)
        else:
            nxt = _stochastic_next(current, transition_model, action, rng)
        reward = reward_from_transition(current, nxt, action)
        total += reward
        cumulative_cost += max(0.0, -reward)
        rewards.append(reward)
        actions.append(action)
        i += 1
    return {
        "seed": int(seed),
        "total_reward": float(total),
        "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
        "cumulative_cost": float(cumulative_cost),
        "negative_reward_rate": float(np.mean(np.asarray(rewards) < 0)) if rewards else 0.0,
        "n_decisions": len(rewards),
        "unique_actions": int(len(set(actions))),
    }


def monte_carlo_policy(panel: pd.DataFrame, q, transition_model, n_simulations: int = 500,
                       seed: int = 2026) -> tuple[pd.DataFrame, dict]:
    if transition_model is None:
        raise ValueError("Monte Carlo de incerteza requer transition_model.")
    seeds = np.random.default_rng(seed).integers(0, 2**32 - 1, size=n_simulations, dtype=np.uint32)
    prediction_cache = {i: transition_model.predict_next(panel.iloc[i]) for i in range(len(panel) - 1)}
    rows = [simulate_policy_once(panel, q, transition_model, int(s), prediction_cache=prediction_cache) for s in seeds]
    df = pd.DataFrame(rows)
    summary = {}
    for col in ["total_reward", "mean_reward", "cumulative_cost", "negative_reward_rate"]:
        x = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy()
        summary[f"mc_{col}_mean"] = float(np.mean(x)) if len(x) else 0.0
        summary[f"mc_{col}_std"] = float(np.std(x, ddof=1)) if len(x) > 1 else 0.0
        if len(x):
            summary[f"mc_{col}_p05"] = float(np.quantile(x, 0.05))
            summary[f"mc_{col}_p50"] = float(np.quantile(x, 0.50))
            summary[f"mc_{col}_p95"] = float(np.quantile(x, 0.95))
    summary["mc_n_simulations"] = int(len(df))
    summary["mc_seed"] = int(seed)
    summary["evaluation_mode"] = "monte_carlo_model_based_simulation"
    return df, summary


def train_multi_seed(panel: pd.DataFrame, config: QConfig, transition_model=None,
                     seeds=(11, 22, 33)) -> tuple[pd.DataFrame, list[dict]]:
    """Treina a mesma configuração em sementes distintas para avaliar estabilidade."""
    rows = []
    models = []
    for seed in seeds:
        cfg = QConfig(alpha=config.alpha, gamma=config.gamma, epsilon=config.epsilon,
                      epsilon_decay=config.epsilon_decay, epsilon_min=config.epsilon_min,
                      episodes=config.episodes, bins=config.bins, seed=int(seed))
        q, history = train_q_learning(panel, cfg, transition_model=transition_model)
        tail = history.tail(max(1, min(30, len(history))))
        rows.append({
            "seed": int(seed),
            "mean_tail_reward": float(tail["reward"].mean()),
            "std_tail_reward": float(tail["reward"].std(ddof=0)),
            "final_epsilon": float(history["epsilon"].iloc[-1]),
            "states": int(len(q)),
        })
        models.append({"seed": int(seed), "q": q, "history": history})
    return pd.DataFrame(rows), models


def confidence_interval(values, confidence: float = 0.95) -> tuple[float, float]:
    x = pd.to_numeric(pd.Series(values), errors="coerce").dropna().to_numpy(dtype=float)
    if len(x) == 0:
        return (0.0, 0.0)
    mean = float(np.mean(x))
    if len(x) == 1:
        return (mean, mean)
    se = float(np.std(x, ddof=1) / np.sqrt(len(x)))
    z = 1.96 if confidence == 0.95 else 1.645
    return (mean - z * se, mean + z * se)
