from pathlib import Path
import logging

from src.orchestration import PipelineRunner


def test_stage_success(tmp_path):
    runner = PipelineRunner(logging.getLogger("test"), tmp_path / "run.json")
    value = runner.run_stage("demo", lambda: 42)
    assert value == 42
    assert runner.results[0].status == "SUCCESS"


def test_optional_stage_uses_fallback(tmp_path):
    runner = PipelineRunner(logging.getLogger("test"), tmp_path / "run.json")

    value = runner.run_stage(
        "optional",
        lambda: (_ for _ in ()).throw(RuntimeError("boom")),
        required=False,
        fallback=[],
    )

    assert value == []
    assert runner.results[0].status == "FAILED_WITH_FALLBACK"


def test_finalize_writes_manifest(tmp_path):
    path = tmp_path / "run.json"
    runner = PipelineRunner(logging.getLogger("test"), path)
    runner.run_stage("demo", lambda: True)
    payload = runner.finalize()

    assert path.exists()
    assert payload["summary"]["success"] == 1
    assert payload["pipeline_status"] == "SUCCESS"
