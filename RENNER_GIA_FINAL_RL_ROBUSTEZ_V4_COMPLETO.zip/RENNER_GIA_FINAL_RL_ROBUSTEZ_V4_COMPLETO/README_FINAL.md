# RENNER GIA — Versão Final

Pipeline de Decision Intelligence para análise financeira, crédito, operação, ESG/clima e GIA.

## Fluxo
RAW → INGESTÃO → QUALIDADE → FILTRAGEM → NORMALIZAÇÃO → DATA MARTS → FEATURES → FORECAST → ESG/CLIMA → ALERTAS → GIA → RELATÓRIO.

## Execução
```bash
python -m pytest -q
python main.py
```

## Entregáveis
- `outputs/Relatorio_Executivo_Renner_GIA_FINAL.md`
- `outputs/renner_gia_FINAL_analysis.xlsx`
- `logs/pipeline.jsonl`
- `data/processed/walk_forward_metrics.csv`

## Fontes
- Workbook financeiro fornecido para o projeto.
- Relatório IFRS S1/S2 / CBPS 1 e 2 fornecido.
- RI Lojas Renner configurado como fonte oficial para catalogação; esta versão não declara download online quando os arquivos não estão disponíveis localmente.

## Regras de integridade
- `ND` permanece como ausência de dado.
- Não há score ESG sintético.
- Não há valores estimados de concorrentes sem fonte comparável.
- Modelos usam validação temporal; não há divisão aleatória para séries temporais.
- Indicadores são calculados somente quando seus componentes existem.


## Auditoria de exportação — V4

Esta entrega inclui todos os módulos importados pelo `main.py`, o arquivo `config/settings.json` e a suíte `tests/`.

Dependências: `statsmodels` é necessária porque `src/models/forecast_advanced.py` utiliza `ARIMA`. `python-docx` foi removida por não ser importada pelo código desta entrega.

Validação desta entrega:
- `python -m compileall -q src main.py`: OK
- `pytest -q`: 28 passed
- execução do `main.py`: todas as etapas anteriores ao RL foram concluídas; o processamento pesado de RL/Monte Carlo excedeu 300 s nesta máquina, portanto não é declarado como execução ponta a ponta concluída.
