import numpy as np
import pandas as pd


def safe_div(a, b):
    b = b.replace(0, np.nan)
    return a / b


def make_features(panel):
    x = panel.copy().sort_index()
    if 'revenue' in x:
        x['revenue_growth_yoy'] = x['revenue'].pct_change(4, fill_method=None)
    if 'net_income' in x and 'revenue' in x:
        x['net_margin'] = safe_div(x['net_income'], x['revenue'])
    if 'ebitda' in x and 'revenue' in x:
        x['ebitda_margin'] = safe_div(x['ebitda'], x['revenue'])
    if 'assets' in x and 'equity' in x:
        x['equity_to_assets'] = safe_div(x['equity'], x['assets'])
        x['leverage_proxy'] = safe_div(x['assets'], x['equity'])
    if 'cash' in x and 'revenue' in x:
        x['cash_to_revenue'] = safe_div(x['cash'], x['revenue'])
    for col in list(x.columns):
        if pd.api.types.is_numeric_dtype(x[col]):
            x[f'{col}_lag1'] = x[col].shift(1)
    return x.replace([np.inf, -np.inf], np.nan)
