import json, logging, uuid
from pathlib import Path
from datetime import datetime, timezone

class JsonFormatter(logging.Formatter):
    def __init__(self, run_id):
        super().__init__(); self.run_id = run_id
    def format(self, record):
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "run_id": self.run_id,
            "level": record.levelname,
            "stage": getattr(record, "stage", "general"),
            "message": record.getMessage(),
        }
        for key in ("elapsed_seconds","rows_input","rows_output","seed","status"):
            if hasattr(record,key): payload[key]=getattr(record,key)
        return json.dumps(payload, ensure_ascii=False)

def setup_logging(log_dir, run_id=None):
    log_dir = Path(log_dir); log_dir.mkdir(parents=True, exist_ok=True)
    run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    logger = logging.getLogger("renner_gia")
    logger.setLevel(logging.INFO); logger.handlers.clear(); logger.propagate=False
    handler = logging.FileHandler(log_dir / "pipeline.jsonl", encoding="utf-8")
    handler.setFormatter(JsonFormatter(run_id)); logger.addHandler(handler)
    console = logging.StreamHandler(); console.setFormatter(logging.Formatter("%(levelname)s | %(message)s")); logger.addHandler(console)
    logger.run_id = run_id
    return logger
