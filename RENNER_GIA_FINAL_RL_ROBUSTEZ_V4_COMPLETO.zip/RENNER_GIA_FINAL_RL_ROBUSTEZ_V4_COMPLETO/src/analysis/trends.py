import pandas as pd

def add_trend_features(df, columns, windows=(4,8)):
    out = df.copy().sort_index()
    for c in columns:
        if c not in out.columns:
            continue
        for w in windows:
            out[f"{c}_rolling_{w}"] = out[c].rolling(w, min_periods=2).mean()
        out[f"{c}_yoy"] = out[c].pct_change(4, fill_method=None)
    return out
