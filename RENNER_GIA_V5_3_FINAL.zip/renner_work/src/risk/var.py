import numpy as np
import pandas as pd

def historical_var(returns, confidence=0.95):
    s=pd.Series(returns,dtype='float64').dropna()
    if len(s)<10: return np.nan
    return float(-s.quantile(1-confidence))

def operating_shock_var(series, confidence=0.95):
    """VaR descritivo da distribuição histórica de variações da série; não é VaR de mercado."""
    s=pd.Series(series,dtype='float64').dropna()
    if len(s)<10: return np.nan
    changes=s.pct_change().dropna()
    return historical_var(changes,confidence)
