import pandas as pd


def build_store_snapshot(frames):
    df = frames.get('stores', pd.DataFrame()).copy()
    if df.empty:
        return df
    return df


def build_operating_panel(frames):
    df = frames.get('operating_data', pd.DataFrame()).copy()
    if df.empty:
        return df
    return df.sort_values(['metric', 'period'])
