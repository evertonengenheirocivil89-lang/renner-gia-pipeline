import numpy as np
import pandas as pd
from .environment import RennerDecisionEnv, ACTIONS, build_state
from .trainer import greedy_policy

def evaluate_policy(panel: pd.DataFrame, q, transition_model=None, start=0, end=None):
    env = RennerDecisionEnv(panel, transition_model=transition_model)
    end = len(panel) - 1 if end is None else min(end, len(panel) - 1)
    env.reset(start); rows = []; total = 0.0; cumulative_cost = 0.0; guard_interventions = 0
    while env.i < end:
        current = env.panel.iloc[env.i]
        state = build_state(current)
        action = greedy_policy(q, state, current)
        next_state, reward, done, info = env.step(action)
        total += reward
        cumulative_cost += max(0.0, -reward)
        rows.append({"period": info.get("period"), "action_id": action, "action": ACTIONS[action],
                     "reward": reward, "cumulative_reward": total, "cumulative_cost": cumulative_cost,
                     "simulated": info.get("simulated", False)})
        if done: break
    result = pd.DataFrame(rows)
    metrics = {"total_reward": float(result["reward"].sum()) if not result.empty else 0.0,
               "mean_reward": float(result["reward"].mean()) if not result.empty else 0.0,
               "std_reward": float(result["reward"].std(ddof=0)) if not result.empty else 0.0,
               "cumulative_cost": float(result["cumulative_cost"].iloc[-1]) if not result.empty else 0.0,
               "negative_reward_rate": float((result["reward"] < 0).mean()) if not result.empty else 0.0,
               "n_decisions": int(len(result)), "evaluation_mode": "model_based_simulation" if transition_model is not None else "observed_transition"}
    return result, metrics
