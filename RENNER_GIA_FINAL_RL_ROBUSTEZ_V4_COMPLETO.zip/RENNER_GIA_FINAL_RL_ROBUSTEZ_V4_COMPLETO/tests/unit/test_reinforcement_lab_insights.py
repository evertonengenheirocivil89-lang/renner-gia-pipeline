import numpy as np
import pandas as pd
from src.reinforcement.trainer import QConfig, train_sarsa
from src.reinforcement.evaluation import evaluate_policy


def make_panel(n=12):
    idx = pd.date_range("2023-01-01", periods=n, freq="QS")
    return pd.DataFrame({
        "revenue_growth": np.linspace(0.01, 0.04, n),
        "net_margin": np.linspace(0.08, 0.10, n),
        "ebitda_margin": np.linspace(0.15, 0.17, n),
        "roic": np.linspace(0.12, 0.15, n),
        "cash_revenue": np.linspace(0.10, 0.12, n),
        "npl_ratio": np.linspace(0.04, 0.035, n),
        "inventory_growth": np.zeros(n),
        "receivables_growth": np.zeros(n),
        "revenue_volatility_4q": np.full(n, 0.02),
        "net_income_volatility_4q": np.full(n, 0.02),
        "climate_risk_score": np.zeros(n),
    }, index=idx)


def test_sarsa_produces_training_history():
    panel = make_panel()
    q, history = train_sarsa(panel, QConfig(episodes=3, seed=7))
    assert q
    assert len(history) == 3
    assert {"reward", "steps", "guard_interventions"}.issubset(history.columns)


def test_evaluation_reports_cumulative_cost():
    panel = make_panel()
    q, _ = train_sarsa(panel, QConfig(episodes=3, seed=7))
    result, metrics = evaluate_policy(panel, q)
    assert "cumulative_cost" in result.columns
    assert "negative_reward_rate" in metrics
