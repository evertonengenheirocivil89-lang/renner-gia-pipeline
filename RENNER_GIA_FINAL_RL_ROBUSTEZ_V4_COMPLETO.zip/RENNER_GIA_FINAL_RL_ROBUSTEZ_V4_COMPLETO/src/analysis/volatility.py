import pandas as pd

def add_volatility(df, columns, window=8):
    out = df.copy().sort_index()
    for c in columns:
        if c not in out.columns:
            continue
        out[f"{c}_volatility"] = out[c].pct_change(fill_method=None).rolling(window, min_periods=3).std()
    return out
