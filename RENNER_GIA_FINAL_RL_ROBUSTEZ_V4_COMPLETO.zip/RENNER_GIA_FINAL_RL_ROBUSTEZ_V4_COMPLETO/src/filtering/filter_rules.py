import pandas as pd

def filter_valid_numeric(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["value_numeric"] = pd.to_numeric(out["value_raw"], errors="coerce")
    out["filter_status"] = "KEEP" 
    out.loc[out["is_nd"], "filter_status"] = "MISSING_ND"
    out.loc[(~out["is_nd"]) & out["value_numeric"].isna(), "filter_status"] = "REVIEW_NON_NUMERIC"
    return out
