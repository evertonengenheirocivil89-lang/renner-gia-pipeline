from pathlib import Path
import pandas as pd


def write_report(path, **tables):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine='openpyxl') as writer:
        for name, df in tables.items():
            if df is None: continue
            if isinstance(df, pd.Series): df = df.to_frame()
            df.to_excel(writer, sheet_name=name[:31])
    return path
