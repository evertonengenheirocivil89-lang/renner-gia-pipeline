# RENNER GIA — V4 Robustez RL

Atualização sobre a V3 auditada.

## Alterações
- missingness explícito no estado RL: valor + indicador de ausência;
- modelo de transição com sigma calibrado por previsões one-step-ahead dentro do desenvolvimento (out-of-sample temporal);
- features totalmente ausentes no bloco de ajuste são excluídas por componente, evitando warnings e pipelines inválidos;
- comparação no mesmo holdout entre Q-Learning, SARSA e baseline MANTER_ESTRATEGIA;
- comparação permanece descritiva/model-based, sem causalidade;
- testes específicos para missingness, sigma temporal e comparabilidade das políticas.

## Validação
28 testes passaram.

## Observação
A execução ponta a ponta pode continuar limitada pelo custo do treinamento RL. Isso é tratado separadamente de testes unitários e validação funcional dos módulos.
