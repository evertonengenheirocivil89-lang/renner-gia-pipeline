from pathlib import Path
import pandas as pd


def inventory_esg_sources(esg_dir):
    rows = []
    for p in sorted(Path(esg_dir).glob('*')):
        if p.is_file() and not p.name.startswith('.'):
            rows.append({'file': p.name, 'extension': p.suffix.lower(), 'status': 'available'})
    return pd.DataFrame(rows)


def build_esg_dataset(esg_dir):
    """Returns only observed files. No synthetic ESG score is generated."""
    return inventory_esg_sources(esg_dir)
