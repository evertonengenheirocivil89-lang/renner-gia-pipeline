import json
from pathlib import Path
import pandas as pd
from src.gia.decision_engine import build_alerts
from src.logging_setup import setup_logging
from src.orchestration import PipelineRunner

def test_dynamic_gia_rules_are_applied():
    df=pd.DataFrame({'revenue_growth':[-0.10,0.02]}, index=pd.to_datetime(['2025-01-01','2025-04-01']))
    rules={'revenue_growth':{'warning':0.01,'critical':-0.05,'direction':'higher_better'}}
    out=build_alerts(df,rules=rules)
    assert out.iloc[0]['status']=='INVESTIGAÇÃO'
    assert out.iloc[1]['status']=='CONTROLE'

def test_runner_manifest_contains_run_id_and_rows(tmp_path):
    logger=setup_logging(tmp_path,run_id='TEST_RUN')
    runner=PipelineRunner(logger,tmp_path/'manifest.json')
    runner.run_stage('x',lambda: pd.DataFrame({'a':[1,2,3]}))
    payload=runner.finalize()
    assert payload['run_id']=='TEST_RUN'
    assert payload['stages'][0]['rows_output']==3

def test_settings_json_is_valid():
    p=Path('config/settings.json')
    data=json.loads(p.read_text())
    assert 'gia_rules' in data and 'risk' in data and 'rl' in data
