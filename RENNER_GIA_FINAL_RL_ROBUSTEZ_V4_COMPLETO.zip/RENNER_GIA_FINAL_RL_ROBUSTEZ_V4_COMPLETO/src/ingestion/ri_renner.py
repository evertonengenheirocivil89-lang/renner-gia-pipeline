from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re
import pandas as pd

RI_URL = 'https://ri.lojasrenner.com.br/'

CATEGORIES = {
    'resultados': ['resultado', 'resultados', 'itr', 'dfp', 'demonstrações', 'demonstracoes', 'release'],
    'operacional': ['operacional', 'indicadores', 'lojas', 'vendas'],
    'apresentacoes': ['apresentação', 'apresentacao', 'presentation', 'teleconferência', 'teleconferencia'],
    'relatorios': ['relatório', 'relatorio', 'anual', 'sustentabilidade', 'esg', 'integrado'],
    'governanca': ['governança', 'governanca', 'assembleia', 'estatuto', 'política', 'politica'],
    'comunicados': ['comunicado', 'fato relevante', 'aviso', 'material'],
}


def classify_document(name):
    s = str(name).casefold()
    for cat, terms in CATEGORIES.items():
        if any(t in s for t in terms):
            return cat
    return 'outros'


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def build_ri_catalog(raw_dir, source_url=RI_URL):
    """Cataloga arquivos já baixados do RI. Não inventa documentos nem metadados."""
    folder = Path(raw_dir) / 'RI'
    folder.mkdir(parents=True, exist_ok=True)
    rows = []
    for p in sorted(folder.rglob('*')):
        if not p.is_file():
            continue
        rel = p.relative_to(folder)
        st = p.stat()
        rows.append({
            'source': 'RI Renner',
            'source_url': source_url,
            'document_name': p.name,
            'relative_path': str(rel),
            'category': classify_document(p.name),
            'extension': p.suffix.lower(),
            'size_bytes': st.st_size,
            'sha256': sha256_file(p),
            'local_modified_at': datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
            'status': 'local_file_available',
        })
    return pd.DataFrame(rows)


def build_ri_manifest(raw_dir, output_path):
    catalog = build_ri_catalog(raw_dir)
    meta = {
        'source_url': RI_URL,
        'generated_at_utc': datetime.now(timezone.utc).isoformat(),
        'online_download_attempted': False,
        'note': 'O ambiente de execução atual não possui acesso externo; o catálogo registra apenas arquivos efetivamente presentes em data/raw/RI.'
    }
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    catalog.to_csv(output_path, index=False)
    Path(output_path).with_suffix('.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
    return catalog, meta


def parse_period_from_name(name):
    s = str(name).upper()
    patterns = [
        (r'(1|2|3|4)T(20\d{2})', lambda m: f'{m.group(2)}-{int(m.group(1))*3:02d}'),
        (r'(1|2|3|4)Q(20\d{2})', lambda m: f'{m.group(2)}-{int(m.group(1))*3:02d}'),
        (r'(20\d{2})', lambda m: m.group(1)),
    ]
    for pat, fn in patterns:
        m = re.search(pat, s)
        if m:
            return fn(m)
    return None


def build_ri_document_register(raw_dir):
    catalog = build_ri_catalog(raw_dir)
    if catalog.empty:
        return catalog
    catalog['period_hint'] = catalog['document_name'].map(parse_period_from_name)
    catalog['document_type'] = catalog['category']
    return catalog
