import numpy as np
import pandas as pd
from src.reinforcement.trainer import QConfig, train_sarsa
from src.reinforcement.policy_diagnostics import evaluate_baseline, evaluate_rl_with_diagnostics, compare_policy_to_baseline


def panel(n=12):
    idx = pd.date_range("2023-01-01", periods=n, freq="QS")
    return pd.DataFrame({
        "revenue_growth": np.linspace(.01,.04,n), "net_margin": np.linspace(.08,.10,n),
        "ebitda_margin": np.linspace(.15,.17,n), "roic": np.linspace(.12,.15,n),
        "cash_revenue": np.linspace(.10,.12,n), "npl_ratio": np.linspace(.04,.035,n),
        "inventory_growth": np.zeros(n), "receivables_growth": np.zeros(n),
        "revenue_volatility_4q": np.full(n,.02), "net_income_volatility_4q": np.full(n,.02),
        "climate_risk_score": np.zeros(n)}, index=idx)


def test_baseline_and_rl_diagnostics_are_comparable():
    p = panel(); q, _ = train_sarsa(p, QConfig(episodes=3, seed=7))
    base, bm = evaluate_baseline(p)
    rl, rm = evaluate_rl_with_diagnostics(p, q)
    cmp = compare_policy_to_baseline(rl, base)
    assert len(base) == len(rl)
    assert "action_switch_rate" in rm
    assert "guard_interventions" in rm
    assert cmp["comparison_scope"] == "descriptive_model_based_simulation"
