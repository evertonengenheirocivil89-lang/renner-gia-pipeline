import pandas as pd
from pathlib import Path

SOURCE = "Relatório de informações financeiras relacionadas à sustentabilidade 2025 – IFRS S1/S2 e CBPS 1/2"

RISK_DATA = [
    {"risk_id":"R1","risk":"Ondas de calor","financial_impact_2025_result_m":-10.0,"future_cf_low_m":94.0,"future_cf_high_m":110.0,"horizon":"10 anos","status_2025":"impacto mensurado","notes":"Impacto no resultado operacional; relacionado a estoque, vendas e markdown."},
    {"risk_id":"R2","risk":"Inundações e tempestades","financial_impact_2025_result_m":0.0,"future_cf_low_m":22.0,"future_cf_high_m":25.0,"horizon":"10 anos","status_2025":"sem impacto financeiro no exercício","notes":"Risco associado a fluxo de clientes, paralisação, infraestrutura e logística."},
    {"risk_id":"R3","risk":"Incêndios florestais","financial_impact_2025_result_m":0.0,"future_cf_low_m":None,"future_cf_high_m":None,"horizon":"N/D","status_2025":"sem impacto financeiro identificado","notes":"CD Cabreúva; medidas de prevenção e continuidade operacional."},
    {"risk_id":"R4","risk":"Ventos fortes","financial_impact_2025_result_m":None,"future_cf_low_m":None,"future_cf_high_m":None,"horizon":"N/D","status_2025":"mensuração conforme relatório","notes":"Risco físico priorizado para lojas, CDs e infraestrutura."},
    {"risk_id":"R5","risk":"Secas meteorológicas","financial_impact_2025_result_m":0.0,"future_cf_low_m":None,"future_cf_high_m":None,"horizon":"N/D","status_2025":"sem impacto financeiro identificado","notes":"Risco relevante qualitativamente para cadeia com uso intensivo de água."},
]

EMISSIONS_2025 = [
    {"year":2025,"scope":"Escopo 1","category":"Total","tco2e":7033.11},
    {"year":2025,"scope":"Escopo 2","category":"Localização","tco2e":11146.36},
    {"year":2025,"scope":"Escopo 2","category":"Escolha de compra","tco2e":0.0},
    {"year":2025,"scope":"Escopo 3","category":"Total reportado","tco2e":398131.26},
]

TARGETS = [
    {"target":"Escopos 1 e 2","baseline_year":2019,"target_year":2030,"target_reduction_pct":46.2,"metric":"redução absoluta de emissões","status_2025":"submeta 2025 alcançada"},
    {"target":"Escopo 3 – bens e serviços adquiridos por peça","baseline_year":2019,"target_year":2030,"target_reduction_pct":55.0,"metric":"redução por peça de vestuário e calçado","status_2025":"submeta 2025 não alcançada"},
    {"target":"Escopos 1, 2 e 3","baseline_year":2019,"target_year":2050,"target_reduction_pct":90.0,"metric":"redução absoluta + compensação residual","status_2025":"meta de longo prazo"},
]

def build_climate_risk_mart():
    return pd.DataFrame(RISK_DATA)

def build_emissions_mart():
    return pd.DataFrame(EMISSIONS_2025)

def build_climate_targets_mart():
    return pd.DataFrame(TARGETS)

def build_climate_opportunity_mart():
    return pd.DataFrame([
        {"item":"Oportunidades climáticas – efeito financeiro atual","value_m":109.0,"unit":"R$ milhões","basis":"resultado operacional 2025; associação específica por oportunidade requer leitura detalhada das respectivas páginas"},
        {"item":"Oportunidades climáticas – efeito financeiro atual","value_m":47.0,"unit":"R$ milhões","basis":"resultado operacional 2025; associação específica por oportunidade requer leitura detalhada das respectivas páginas"},
        {"item":"Oportunidades climáticas – efeito financeiro futuro","value_low_m":166.0,"value_high_m":193.0,"unit":"R$ milhões","basis":"fluxo de caixa em 10 anos, conforme divulgação estruturada localizada"},
    ])
