import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

def arima_forecast(df, column, periods=4, order=(1,1,1), min_points=16):
    if column not in df.columns:
        return {"status":"MISSING","forecast":pd.Series(dtype=float)}
    s = df.sort_index()[column].dropna()
    if len(s) < min_points:
        return {"status":"INSUFFICIENT_DATA","forecast":pd.Series(dtype=float)}
    try:
        # Convert irregular date indexes to quarterly PeriodIndex so statsmodels
        # retains a valid frequency for the forecast horizon.
        if isinstance(s.index, pd.DatetimeIndex):
            s.index = s.index.to_period("Q")
        model = ARIMA(s, order=order).fit()
        fc = model.forecast(periods)
        return {"status":"OK","forecast":fc}
    except Exception as exc:
        return {"status":f"ERROR: {exc}","forecast":pd.Series(dtype=float)}
