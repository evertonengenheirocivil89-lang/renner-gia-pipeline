from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd

ACTIONS = {
    0: "MANTER_ESTRATEGIA",
    1: "AUMENTAR_ESTOQUE",
    2: "REDUZIR_ESTOQUE",
    3: "AUMENTAR_PROMOCAO",
    4: "REDUZIR_PROMOCAO",
    5: "AUMENTAR_INVESTIMENTO",
    6: "REDUZIR_INVESTIMENTO",
    7: "AUMENTAR_CONTROLE_CREDITO",
    8: "REDUZIR_EXPOSICAO_CREDITO",
}

@dataclass
class RewardWeights:
    profit: float = 0.30
    roic: float = 0.20
    cash: float = 0.15
    revenue: float = 0.10
    risk: float = 0.10
    npl: float = 0.10
    volatility: float = 0.05


def _clip_score(x, lo=-3.0, hi=3.0):
    return float(np.clip(x, lo, hi))


def build_state(row: pd.Series) -> np.ndarray:
    """Estado observável com valor imputado + indicador explícito de ausência."""
    cols = [
        "revenue_growth", "net_margin", "ebitda_margin", "roic",
        "cash_revenue", "npl_ratio", "inventory_growth", "receivables_growth",
        "revenue_volatility_4q", "net_income_volatility_4q", "climate_risk_score",
    ]
    values, missing = [], []
    for c in cols:
        v = pd.to_numeric(row.get(c, np.nan), errors="coerce")
        is_missing = bool(pd.isna(v))
        values.append(0.0 if is_missing else float(v))
        missing.append(1.0 if is_missing else 0.0)
    return np.asarray(values + missing, dtype=np.float32)


def policy_guard(action: int, row: pd.Series) -> int:
    """Guarda de governança: restringe ações quando há sinais financeiros críticos."""
    cash = float(pd.to_numeric(row.get("cash_revenue", np.nan), errors="coerce") or 0.0)
    npl = float(pd.to_numeric(row.get("npl_ratio", np.nan), errors="coerce") or 0.0)
    if cash < 0.05 and action == 5:
        return 0
    if npl > 0.08 and action == 1:
        return 7
    return int(action)


ACTION_EFFECTS = {
    0: {},
    1: {"revenue_growth": 0.20, "cash_revenue": -0.15, "net_margin": -0.10},
    2: {"revenue_growth": -0.10, "cash_revenue": 0.15, "net_margin": 0.05},
    3: {"revenue_growth": 0.25, "net_margin": -0.25},
    4: {"revenue_growth": -0.08, "net_margin": 0.15},
    5: {"revenue_growth": 0.15, "roic": -0.15, "cash_revenue": -0.20},
    6: {"revenue_growth": -0.10, "roic": 0.10, "cash_revenue": 0.18},
    7: {"npl_ratio": -0.30, "revenue_growth": -0.08, "net_margin": 0.08},
    8: {"npl_ratio": -0.18, "cash_revenue": 0.12, "revenue_growth": -0.10},
}

def apply_action_scenario(predicted: pd.Series, current: pd.Series, transition_model, action: int) -> pd.Series:
    """Aplica a intervenção em unidades da volatilidade residual do modelo."""
    nxt = predicted.copy()
    for col, multiplier in ACTION_EFFECTS.get(int(action), {}).items():
        sigma = float(transition_model.residual_std.get(col, 0.0))
        # Limite de segurança: no máximo 1 desvio residual por decisão.
        effect = float(np.clip(multiplier * sigma, -sigma, sigma))
        if col in nxt.index and np.isfinite(effect):
            nxt[col] = float(nxt[col]) + effect
    return nxt

def reward_from_transition(current: pd.Series, nxt: pd.Series, action: int,
                           weights: RewardWeights = RewardWeights()) -> float:
    def val(s, c):
        x = pd.to_numeric(s.get(c, np.nan), errors="coerce")
        return np.nan if pd.isna(x) else float(x)
    def delta(c):
        a, b = val(current, c), val(nxt, c)
        if np.isnan(a) or np.isnan(b):
            return 0.0
        return _clip_score(b - a)
    profit = delta("net_margin")
    roic = delta("roic")
    cash = delta("cash_revenue")
    revenue = delta("revenue_growth")
    risk = -delta("climate_risk_score")
    npl = -delta("npl_ratio")
    volatility = -delta("revenue_volatility_4q")
    reward = (weights.profit * profit + weights.roic * roic + weights.cash * cash
              + weights.revenue * revenue + weights.risk * risk
              + weights.npl * npl + weights.volatility * volatility)
    if action != 0:
        reward -= 0.01
    return float(reward)


class RennerDecisionEnv:
    """Ambiente offline com modelo de transição aprendido no desenvolvimento."""
    def __init__(self, panel: pd.DataFrame, transition_model=None, weights=None):
        self.panel = panel.sort_index().copy()
        self.weights = weights or RewardWeights()
        self.transition_model = transition_model
        self.actions = ACTIONS
        self.i = 0
        # A transição é determinística dado o estado atual; pré-calcular uma vez
        # evita repetir previsões do Ridge a cada episódio de treinamento.
        self._pred_cache = {}
        if self.transition_model is not None:
            for i in range(max(0, len(self.panel) - 1)):
                self._pred_cache[i] = self.transition_model.predict_next(self.panel.iloc[i])

    def reset(self, start=0):
        self.i = int(start)
        return build_state(self.panel.iloc[self.i])

    def step(self, action: int):
        action = policy_guard(action, self.panel.iloc[self.i])
        current = self.panel.iloc[self.i]
        if self.i >= len(self.panel) - 1:
            return build_state(current), 0.0, True, {"action": action}
        if self.transition_model is None:
            nxt = self.panel.iloc[self.i + 1].copy()
        else:
            if self.i not in self._pred_cache:
                self._pred_cache[self.i] = self.transition_model.predict_next(current)
            pred = self._pred_cache[self.i]
            nxt = current.copy()
            for c, v in pred.items():
                nxt[c] = v
            nxt = apply_action_scenario(nxt, current, self.transition_model, action)
        self.i += 1
        reward = reward_from_transition(current, nxt, action, self.weights)
        done = self.i >= len(self.panel) - 1
        return build_state(nxt), reward, done, {"action": action, "period": str(self.panel.index[self.i]), "simulated": self.transition_model is not None}
