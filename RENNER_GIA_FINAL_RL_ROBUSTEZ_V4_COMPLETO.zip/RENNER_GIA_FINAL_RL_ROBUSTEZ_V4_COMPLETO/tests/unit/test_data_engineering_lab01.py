import pandas as pd
from src.etl.data_engineering_lab import prepare_lab01_dataset, profile_dataset, ranking_tables


def test_lab01_creates_derived_metrics():
    panel = pd.DataFrame({
        "revenue": [100.0, 200.0],
        "net_income": [10.0, 30.0],
        "assets": [500.0, 600.0],
        "equity": [100.0, 150.0],
    }, index=pd.to_datetime(["2025-01-01", "2025-04-01"]))
    panel.index.name = "period"
    out = prepare_lab01_dataset(panel)
    assert "receita_por_ativo" in out.columns
    assert "lucro_por_receita" in out.columns
    assert out.loc[0, "receita_por_ativo"] == 0.2
    assert out.loc[1, "lucro_por_receita"] == 0.15


def test_lab01_profile_and_ranking():
    panel = pd.DataFrame({"revenue": [100.0, 300.0], "assets": [500.0, 600.0]},
                         index=pd.to_datetime(["2025-01-01", "2025-04-01"]))
    panel.index.name = "period"
    out = prepare_lab01_dataset(panel)
    profile = profile_dataset(out)
    ranks = ranking_tables(out, n=1)
    assert profile["shape_rows"] == 2
    assert profile["shape_columns"] >= 4
    assert ranks["top_revenue"].iloc[0]["revenue"] == 300.0
