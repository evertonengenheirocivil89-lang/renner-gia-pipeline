import pandas as pd


def missingness_report(df):
    if df.empty: return pd.DataFrame(columns=['column','missing','missing_pct','dtype'])
    return pd.DataFrame({
        'column': df.columns,
        'missing': df.isna().sum().values,
        'missing_pct': (df.isna().mean().values * 100).round(2),
        'dtype': [str(x) for x in df.dtypes],
    }).sort_values('missing_pct', ascending=False)
